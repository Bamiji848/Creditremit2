from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from app import views
from django.contrib.auth.views import (
    PasswordResetView, 
    PasswordResetDoneView, 
    PasswordResetConfirmView,
    PasswordResetCompleteView,
    PasswordChangeView,
    PasswordChangeDoneView,
)

urlpatterns = [
    path('',views.index,name="index"),
    path('about-us/',views.about,name="about"),
    path('terms-and-condition/',views.terms,name='terms'),
    path('privacy/',views.privacy,name='privacy'),
    path('password-reset/', PasswordResetView.as_view(template_name='registration/password_reset.html'),name='password-reset'),
    path('password-change/', PasswordChangeView.as_view(template_name='registration/password_change_form.html'),name='password-change'),
    path('password_change_done/', PasswordChangeDoneView.as_view(template_name='registration/password_change_done.html'),name='password_change_done'),
    path('password-reset/done/', PasswordResetDoneView.as_view(template_name='registration/reset_password_done.html'),name='password_reset_done'),
    path('password-reset-confirm/<uidb64>/<token>/', PasswordResetConfirmView.as_view(template_name='registration/password_reset_confirm.html'),name='password_reset_confirm'),
    path('password-reset-complete/',PasswordResetCompleteView.as_view(template_name='registration/password_reset_complete.html'),name='password_reset_complete'),
    path('dashboard/',views.dashboard,name='dashboard'),
    path('success/',views.success,name='success'),
    path('add-bank/',views.add_bank,name='add_bank'),
    path('kyc-verification-required/',views.uploadkycmessage,name='uploadkycmessage'),
    path('kyc/',views.kyc,name='kyc'),
    path('kycverified/',views.kycverified,name='kycverified'),
    path('sign-up/',views.register,name='register'),
    path('adminpage/', include('adminpage.urls', namespace='adminpage')),
    path('accounts/', include('accounts.urls', namespace='accounts')),
    path('transactions/',include('transactions.urls', namespace='transactions')),
    # path('accounts/', include('django.contrib.auth.urls')),
    path('admin/', admin.site.urls),
]

if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL,
                          document_root=settings.STATIC_URL)
    urlpatterns += static(settings.MEDIA_URL,
                          document_root=settings.MEDIA_ROOT)