from django.shortcuts import render,redirect
from transactions.models import *
from django.utils import timezone
from datetime import date
from transactions.constants import DEPOSIT, WITHDRAWAL
from accounts.forms import KycForm,BankForm
from django.contrib import messages
from accounts.models import User
from django.shortcuts import get_object_or_404
from django.http import Http404, HttpResponse, HttpResponseRedirect
from django.contrib.auth.decorators import login_required
from transactions.models import Rate

# Create your views here.
def index(request):
    rater = Rate.objects.get(id=1)
    rater2 = Rate.objects.get(id=2)
    rate = rater.rate
    ngrate = rater2.rate
    return render(request,'app/index.html',context={'rate':rate,'ngrate':ngrate})

def login(request):
    return render(request,'registration/login.html')
    
def terms(request):
    return render(request,'app/terms.html')
    
def privacy(request):
    return render(request,'app/privacy.html')
    
def about(request):
    return render(request,'app/about.html')

@login_required(login_url='/dashboard/')
def dashboard(request):
    rater = Rate.objects.get(id=1)
    ratetoday = rater.rate
    user = request.user
    account = user.account
    trans = Transaction.objects.filter(account=account,transaction_type=DEPOSIT)
    tra = Transaction.objects.filter(account=account)
    now = date.today()
    trans1 = Transaction.objects.filter(endtimestamp=now,account=account,transaction_type=DEPOSIT)
    t = Transaction.objects.filter(endtimestamp=now,account=account,paid=True,approved=True,transaction_type=DEPOSIT)
    to = sum(trans1.values_list('amount', flat=True))
    tot = sum(trans.values_list('amount', flat=True))
    dep = Transaction.objects.filter(account=account,paid=True,approved=True,transaction_type=DEPOSIT)
    dept = sum(dep.values_list('amount',flat=True))
    ts = sum(t.values_list('amount',flat=True))
    tra1 = sum(tra.values_list('amount',flat=True))
    av = trans1.count()
    av2 = trans.count()
    av3 = t.count()
    try:
        bounce_rate = (Transaction.objects.filter(account=account,approved=False).count()/Transaction.objects.filter(account=account).count())*100
        return render(request,'Dashboard/index.html',context={'bounce_rate':bounce_rate,'user':user,'ratetoday':ratetoday,'account':account,'trans':trans,'trans1':trans1,'tra1':tra1,'now':now,'to':to,'tot':tot,'av':av,'tra':tra,'av2':av2,'av3':av3,'ts':ts,'dept':dept,})
    except ZeroDivisionError:
        pass
    context = {
        'user':user,
        'ratetoday':ratetoday,
        'account':account,
        'trans':trans,
        'trans1':trans1,
        'tra1':tra1,
        'now':now,
        'to':to,
        'tot':tot,
        'av':av,
        'tra':tra,
        'av2':av2,
        'av3':av3,
        'ts':ts,
        'dept':dept,
    }
    return render(request,'Dashboard/index.html',context)

def register(request):
    return render(request,'registration/register.html')

def success(request):
    return render(request,'app/success.html')
    
@login_required(login_url='/dashboard/')
def kyc(request):
    rater = Rate.objects.get(id=1)
    ratetoday = rater.rate
    if request.method == 'POST':
        form = KycForm(request.POST,request.FILES)
        if form.is_valid():
            user = request.user
            dt = form.save(commit=False)
            dt.user = user
            dt.save()
            messages.success(request,'Successful Upload, Awaiting Confirmation')
            return redirect('kyc')
    form = KycForm()
    return render(request,'app/kyc.html',context={'form':form,'ratetoday':ratetoday})

@login_required(login_url='/dashboard/')
def kycverified(request):
    user = request.user.email
    portal = get_object_or_404(User, email=user)
    try:
        portal.kycverified = True
        portal.save()
        messages.success(request,'KYC Verification Successful')
        return redirect('kyc')
    except User.DoesNotExist:
        Http404('The page you are accessing does not exist')
    return render(request,'accounts/kyc.html',{'portal': portal})

@login_required(login_url='/dashboard/')    
def uploadkycmessage(request):
    return render(request,'accounts/kycmessage.html')
 
@login_required(login_url='/dashboard/')    
def add_bank(request):
    form = BankForm(request.POST or None)
    if request.method == "POST":
        if form.is_valid():
            user = request.user
            dt = form.save(commit=False)
            dt.user = user
            dt.save()
            messages.success(request,'Bank added successfully')
            return redirect('add_bank')
    return render(request,'app/add-bank.html',{'form':form})
