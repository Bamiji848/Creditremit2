from django.db.models.signals import post_save
from accounts.models import User
from django.dispatch import receiver
from accounts.models import UserBankAccount
from django.conf import settings
from django.utils import timezone
# from pinax.referrals.models import Referral,ReferralResponse
from accounts.utils import create_new_ref_number
from django.urls import reverse
from django.core.mail import EmailMessage
from django.contrib.sites.shortcuts import get_current_site
from django.template.loader import render_to_string
from django.http import request

@receiver(post_save, sender=User)
def create_account(sender,instance,created, **kwargs):
    user=instance
    if created:
        UserBankAccount.objects.create(
                user=user,
                initial_deposit_date=timezone.now(),
                account_no=user.id+settings.ACCOUNT_NUMBER_START_FROM
            )
        # referral = Referral.create(
        #         user=instance,
        #         redirect_to=reverse("accounts:user_registration")
        #     )
        # user.referralfield = referral
        # user.save()
        # current_site = get_current_site(request)
        # mail_subject = 'Group Forte Referral.'
        # message = render_to_string('accounts/referral_email1.html', {
        #         'user': user,
        #         'domain': current_site.domain,
        # })
        # to_email = user.email
        # email = EmailMessage(
        # mail_subject, message, to=[to_email]
        #     )
        # email.content_subtype = 'html'
        # email.send()
        
@receiver(post_save,sender=User)
def save_account(sender,instance, **kwargs):
    instance.account.save()