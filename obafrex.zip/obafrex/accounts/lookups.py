from ajax_select import register, LookupChannel
from accounts.models import User
from django.utils.html import escape
from django.db.models import Q


@register('user')
class UserLookup(LookupChannel):
    model = User

    def get_query(self, q, request):
        return User.objects.filter(email__icontains=q).order_by('email')

    def get_result(self, obj):
        return obj.email

    def format_match(self, obj):
        return self.format_item_display(obj)

    def format_item_display(self, obj):
        return u"%s" % escape(obj.email)
