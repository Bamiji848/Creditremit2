import math
import random


def create_new_ref_number():
    digits = "0123456789"
    OTP = ""

    for i in range(10):
        OTP += digits[math.floor(random.random()*10)]
    return OTP
