from django.contrib import messages
from django.http.response import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from accounts.forms import CreateUser
from django.core.mail import send_mail
from django.conf import settings
# from django.contrib.auth.models import User
import random
from accounts.models import PreRegistration,User
from .forms import VerifyForm,LoginForm
from django.contrib.auth import login,logout,authenticate
# Create your views here.
from django.utils.html import strip_tags
from django.template.loader import render_to_string
from django.core import mail

def creatingOTP():
    otp = ""
    for i in range(6):
        otp+= f'{random.randint(0,6)}'
    return otp

def sendEmail(email):
    otp = creatingOTP()
    subject = 'One Time Password'
    html_message = render_to_string('app/email.html', {'otp': otp,'email':email})
    plain_message = strip_tags(html_message)
    from_email = settings.EMAIL_HOST_USER
    to = email
    
    mail.send_mail(subject, plain_message, from_email, [to], html_message=html_message)
    # send_mail(
    # 'One Time Password',
    # f'Your OTP pin is {otp}',
    # settings.EMAIL_HOST_USER,
    # [email],
    # fail_silently=False,
    # )
    return otp


def user_registration(request):
    if not request.user.is_authenticated:
        if request.method == 'POST':
            form = CreateUser(request.POST)
            if form.is_valid():
                email = form.cleaned_data['email']
                otp = sendEmail(email)
                dt = PreRegistration(firstname=form.cleaned_data['firstname'],lastname=form.cleaned_data['lastname'],username= form.cleaned_data['name'],email=email,otp=otp,password1 = form.cleaned_data['password1'],password2 = form.cleaned_data['password2'],phone_number=form.cleaned_data['phone_number'],country=form.cleaned_data['country'])
                dt.save()
                return HttpResponseRedirect('/accounts/verify/')
        else:
            form = CreateUser()
        return render(request,"accounts/register.html",{'form':form})
    else:
        return HttpResponseRedirect('/dashboard/')

def user_login(request):
    if not request.user.is_authenticated:
        if request.method == 'POST':
            form = LoginForm(request=request,data=request.POST)
            if form.is_valid():
                username = form.cleaned_data['username']
                password = form.cleaned_data['password']
                usr = authenticate(username=username,password = password)
                if usr is not None:
                    login(request,usr)
                    return HttpResponseRedirect('/dashboard/')
        else:
            form = LoginForm()
        return render(request,'accounts/login.html',{'form':form})
    else:
        return HttpResponseRedirect('/dashboard/')

def verifyUser(request):
    if not request.user.is_authenticated:
        if request.method == 'POST':
            form = VerifyForm(request.POST)
            if form.is_valid():
                otp = form.cleaned_data['otp']
                data = PreRegistration.objects.filter(otp = otp)
                if data:
                    name = ''
                    firstname = ''
                    lastname = ''
                    email = ''
                    phone_number = ''
                    country = ''
                    password1 = ''
                    for i in data:
                        print(i.firstname)
                        username = i.username
                        firstname = i.firstname
                        lastname = i.lastname
                        email = i.email
                        phone_number = i.phone_number
                        country = i.country
                        password1 = i.password1

                    user = User.objects.create_user(email, password1)
                    user.firstname = firstname
                    user.lastname = lastname
                    user.phone_number = phone_number
                    user.country = country
                    user.name = username
                    user.save()
                    user.kycverified = False
                    user.save()
                    data.delete()
                    messages.success(request,'Account is created successfully!')
                    return HttpResponseRedirect('/accounts/verify/')   
                else:
                    messages.success(request,'Entered OTP is wrong')
                    return HttpResponseRedirect('/accounts/verify/')
        else:            
            form = VerifyForm()
        return render(request,'accounts/verify.html',{'form':form})
    else:
        return HttpResponseRedirect('/home/')

def success(request):
    if request.user.is_authenticated:
        return render(request,'accounts/success.html')
    else:
        return HttpResponseRedirect('/')

def user_logout(request):
    if request.user.is_authenticated:
        logout(request)
        return HttpResponseRedirect('/')
    else:
        return HttpResponseRedirect('/')