from django import forms
from django.contrib.auth.forms import UserCreationForm,AuthenticationForm,UsernameField
# from djan import User
from django.core import validators
from accounts.models import Country,User,Kyc,GetSupport,RecipientAccount
from phonenumber_field.formfields import PhoneNumberField
from phonenumber_field.widgets import PhoneNumberPrefixWidget
from datetime import date
from django.core.exceptions import ValidationError

def validete_username(value):
    if len(value)<=2:
        raise forms.ValidationError(f"Your username cannot be of {len(value)}  word")

class CreateUser(UserCreationForm):
    country = forms.ModelChoiceField(label="Country of Residence", queryset=Country.objects.all(
    ), widget=forms.Select(attrs={'class': 'form-control'}))
    phone_number = PhoneNumberField(
        widget=PhoneNumberPrefixWidget(initial='US')
    )
    class Meta:
        model = User
        fields = [
            'firstname',
            'lastname',
            'name',
            'email',
            'country',
            'phone_number',
            'password1',
            'password2',
        ]
        widgets = {
            'firstname': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Firstname'}),
            'lastname': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Lastname'}),
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Username'}),
            'email': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Email'}),
            'phone_number': forms.TextInput(attrs={'class': 'form-control'}),
            'country': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Location'}),
            'password1': forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Password'}),
            'password2': forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Confirm password'}),
        }
    
    # def __init__(self, *args, **kwargs):
    #     super(CreateUser, self).__init__(*args, **kwargs)

    #     for fieldname in ['firstname','lastname', 'name','email','phone_number','country','password1', 'password2', 'referredby', 'terms', ]:
    #         self.fields[fieldname].help_text = None
    #         self.fields[fieldname].required = True


class VerifyForm(forms.Form):
    otp = forms.CharField(label='OTP',max_length=70,widget=forms.TextInput(attrs={'class':'form-control','placeholder':'OTP','required':True}),error_messages={'required':'Enter a otp'})


class LoginForm(AuthenticationForm):
    username = UsernameField(widget=forms.TextInput(attrs={"placeholder":"Username","class":"form-control"}))
    password = forms.CharField(widget=forms.PasswordInput(attrs={"placeholder":"password",'autocomplete':'current-password',"class":"form-control"}))  
    
class DateInput(forms.DateInput):
    input_type = 'date'

class KycForm(forms.ModelForm):
    current_year = date.today().year - 16
    YEARS = [x for x in range(1940, current_year)]
    phone_number = PhoneNumberField(
        widget=PhoneNumberPrefixWidget(initial='NG')
    )
    birthday = forms.DateField(
        label='Date of Birth', widget=forms.SelectDateWidget(years=YEARS))
    class Meta:
        model = Kyc
        fields = '__all__'
        exclude = ('user','done',)
        
class SupportForm(forms.ModelForm):
    message = forms.CharField(widget=forms.Textarea(attrs={"rows":"5"}))
    class Meta:
        model = GetSupport
        fields = '__all__'
        exclude = ('name','email','open',)
        
class BankForm(forms.ModelForm):
    class Meta:
        model = RecipientAccount
        fields = ('country','bank_name','account_name','account_number',)
        exclude = ('user',)
        
    def clean(self):
        account_number = self.cleaned_data.get("account_number")
        if len(str(account_number)) > 10:
            raise ValidationError("Account number cannot be more than 10 digits")
        elif len(str(account_number)) < 10:
            raise ValidationError("Account number cannot be less than 10 digits")
        else:
            pass
              
    