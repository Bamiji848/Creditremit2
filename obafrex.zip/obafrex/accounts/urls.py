# from accounts.views import UserAutocomplete
from django.urls import path
# from .views import UserRegistrationView, LogoutView, UserLoginView
from accounts import views
from django.conf.urls import url, include

app_name = 'accounts'

urlpatterns = [
    path(
        "login/", views.user_login,
        name="user_login"
    ),
    path(
        "logout/", views.user_logout,
        name="user_logout"
    ),
    path(
        "register/", views.user_registration,
        name="user_registration"
    ),
    path('verify/',views.verifyUser,name="verify"),
    path('success/',views.success,name="success"),
]
