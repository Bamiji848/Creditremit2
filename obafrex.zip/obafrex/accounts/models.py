from decimal import Decimal
from typing import Any

from django.contrib.auth.models import AbstractUser
from django.core.validators import (
    MinValueValidator,
    MaxValueValidator,
)
from django.db import models
from phonenumber_field.modelfields import PhoneNumberField
from .constants import GENDER_CHOICE
from .managers import UserManager
from django.conf import settings

class PreRegistration(models.Model):
    username = models.CharField(max_length=100)
    firstname = models.CharField(max_length=100)
    lastname = models.CharField(max_length=100)
    email = models.CharField(max_length=100)
    phone_number = models.CharField(max_length=3000)
    country = models.CharField(max_length=3000,verbose_name="Country of Residence")
    password1 = models.CharField(max_length=100)
    password2 = models.CharField(max_length=100)
    otp = models.CharField(max_length=10)

class Country(models.Model):
    country = models.CharField(max_length=500, verbose_name='Country')

    def __str__(self):
        return self.country

class User(AbstractUser):
    username = None
    email = models.EmailField(unique=True, null=False,
                              blank=False)
    firstname = models.CharField(max_length=500)
    lastname = models.CharField(max_length=500)
    name = models.CharField(max_length=500,verbose_name='Username')
    phone_number = PhoneNumberField(null=True,blank=True)
    country = models.CharField(verbose_name="Country",null=True,blank=True,max_length=10000)
    kycverified = models.BooleanField(default=True)
    objects = UserManager()
    
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = []

    def __str__(self):
        return self.email

    @property
    def balance(self):
        if hasattr(self, 'account'):
            return self.account.balance
        return 0

class UserBankAccount(models.Model):
    user = models.OneToOneField(
        User,
        related_name='account',
        on_delete=models.CASCADE,
    )
    account_no = models.PositiveIntegerField(unique=True)
    referral_bonus = models.DecimalField(
        default=0,
        max_digits=12,
        decimal_places=2
    )
    balance = models.DecimalField(
        default=0,
        max_digits=12,
        decimal_places=2
    )
    amount = models.DecimalField(
        default=0,
        max_digits=12,
        decimal_places=2
    )
    interest = models.DecimalField(
        default=0,
        max_digits=12,
        decimal_places=2
    )
    interestday1 = models.DecimalField(
        default=0,
        max_digits=12,
        decimal_places=2
    )
    interestday2 = models.DecimalField(
        default=0,
        max_digits=12,
        decimal_places=2
    )
    interestday3 = models.DecimalField(
        default=0,
        max_digits=12,
        decimal_places=2
    )
    interestday4 = models.DecimalField(
        default=0,
        max_digits=12,
        decimal_places=2
    )
    interestday5 = models.DecimalField(
        default=0,
        max_digits=12,
        decimal_places=2
    )
    interestday6 = models.DecimalField(
        default=0,
        max_digits=12,
        decimal_places=2
    )
    interestday7 = models.DecimalField(
        default=0,
        max_digits=12,
        decimal_places=2
    )
    interestday8 = models.DecimalField(
        default=0,
        max_digits=12,
        decimal_places=2
    )
    interestday9 = models.DecimalField(
        default=0,
        max_digits=12,
        decimal_places=2
    )
    interestday10 = models.DecimalField(
        default=0,
        max_digits=12,
        decimal_places=2
    )
    interestday11 = models.DecimalField(
        default=0,
        max_digits=12,
        decimal_places=2
    )
    interestday12 = models.DecimalField(
        default=0,
        max_digits=12,
        decimal_places=2
    )
    interestday13 = models.DecimalField(
        default=0,
        max_digits=12,
        decimal_places=2
    )
    interestday14 = models.DecimalField(
        default=0,
        max_digits=12,
        decimal_places=2
    )
    interestday15 = models.DecimalField(
        default=0,
        max_digits=12,
        decimal_places=2
    )
    interestday16 = models.DecimalField(
        default=0,
        max_digits=12,
        decimal_places=2
    )
    interestday17 = models.DecimalField(
        default=0,
        max_digits=12,
        decimal_places=2
    )
    interestday18 = models.DecimalField(
        default=0,
        max_digits=12,
        decimal_places=2
    )
    interestday19 = models.DecimalField(
        default=0,
        max_digits=12,
        decimal_places=2
    )
    interestday20 = models.DecimalField(
        default=0,
        max_digits=12,
        decimal_places=2
    )
    interestday21 = models.DecimalField(
        default=0,
        max_digits=12,
        decimal_places=2
    )
    interestday22 = models.DecimalField(
        default=0,
        max_digits=12,
        decimal_places=2
    )
    interestday23 = models.DecimalField(
        default=0,
        max_digits=12,
        decimal_places=2
    )
    interestday24 = models.DecimalField(
        default=0,
        max_digits=12,
        decimal_places=2
    )
    interestday25 = models.DecimalField(
        default=0,
        max_digits=12,
        decimal_places=2
    )
    interestday26 = models.DecimalField(
        default=0,
        max_digits=12,
        decimal_places=2
    )
    interestday27 = models.DecimalField(
        default=0,
        max_digits=12,
        decimal_places=2
    )
    interestday28 = models.DecimalField(
        default=0,
        max_digits=12,
        decimal_places=2
    )
    interestday29 = models.DecimalField(
        default=0,
        max_digits=12,
        decimal_places=2
    )
    interestday30 = models.DecimalField(
        default=0,
        max_digits=12,
        decimal_places=2
    )
    newamount = models.DecimalField(
        default=0,
        max_digits=12,
        decimal_places=2
    )
    interest_start_date = models.DateField(
        null=True, blank=True,
        help_text=(
            'The month number that investment calculation will expire'
        )
    )
    initial_deposit_date = models.DateField(null=True, blank=True)

    def __str__(self):
        return str(self.user)

    def get_interest_calculation_months(self):
        """
        List of month numbers for which the interest will be calculated

        returns [2, 4, 6, 8, 10, 12] for every 2 months interval
        """
        interval = int(
            12 / self.account_type.interest_calculation_per_year
        )
        start = self.interest_start_date.month
        return [i for i in range(start, 13, interval)]


class UserAddress(models.Model):
    user = models.OneToOneField(
        User,
        related_name='address',
        on_delete=models.CASCADE,
    )
    street_address = models.CharField(max_length=512)
    city = models.CharField(max_length=256)
    postal_code = models.PositiveIntegerField()
    country = models.CharField(max_length=256)

    def __str__(self):
        return self.user.email

class Kyc(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL,
                             on_delete=models.CASCADE, null=True)
    passport_nid = models.ImageField(upload_to='images',verbose_name='Passport or National ID')
    # drivers_licence = models.ImageField(upload_to='images',null=True,blank=True,verbose_name="Driver's Licence")
    phone_number = PhoneNumberField(null=True,blank=True, verbose_name="Phone Number")
    zipcode = models.PositiveIntegerField(verbose_name="Zip Code")
    birthday = models.CharField(verbose_name='Date Of Birth', max_length=200)
    done = models.BooleanField(default=False)
    
    def __str__(self):
        return str(self.user)
    
class Priority(models.Model):
    priority = models.CharField(max_length=2000)
    
    def __str__(self):
        return self.priority
    
class GetSupport(models.Model):
    name = models.CharField(max_length=300, verbose_name='Name',blank=True,null=True)
    email = models.EmailField(null=False,
                              blank=False)
    subject = models.CharField(max_length=2000,verbose_name='Subject')
    priority = models.ForeignKey(Priority,on_delete=models.CASCADE)
    message = models.TextField(max_length=100000)
    attachment = models.ImageField(upload_to='images', verbose_name='Attachments',null=True,blank=True)
    open = models.BooleanField(default=True)
    
    def __str__(self):
        return self.name
        
class CountryBank(models.Model):
    country = models.CharField(max_length=10000)
    
    def __str__(self):
        return self.country   
    
class RecipientAccount(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL,
                             on_delete=models.CASCADE, null=True)
    country = models.ForeignKey(CountryBank,on_delete=models.CASCADE,verbose_name="Account Denomination")
    bank_name = models.CharField(max_length=7000,verbose_name="Bank")
    account_name = models.CharField(max_length=7000,verbose_name="Name on Account(Please use name as written on your Means of identification)")
    account_number = models.PositiveBigIntegerField(verbose_name="Account Number")
    
    def __str__(self):
        return (self.bank_name + "-" + str(self.account_number) + "-" + str(self.account_name))
    