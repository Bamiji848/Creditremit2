from django.contrib import admin

from .models import User, UserAddress, UserBankAccount,Country,Kyc,Priority,GetSupport,RecipientAccount,CountryBank

admin.site.register(Country)
admin.site.register(User)
admin.site.register(UserAddress)
admin.site.register(UserBankAccount)
admin.site.register(Kyc)
admin.site.register(Priority)
admin.site.register(GetSupport)
admin.site.register(RecipientAccount)
admin.site.register(CountryBank)