DEPOSIT = 1
WITHDRAWAL = 2
TRANSFER = 3
INVEST = 4

STAGE_1 = "1"
STAGE_2 = "2"
STAGE_3 = "3"
COMPLETE = "Complete"

STAGE_ORDER = [STAGE_1, STAGE_2, STAGE_3, COMPLETE]

TRANSACTION_TYPE_CHOICES = (
    (DEPOSIT, 'Deposit'),
    (WITHDRAWAL, 'Withdrawal'),
    (TRANSFER, 'Transfer'),
    (INVEST, 'Invest'),
)
