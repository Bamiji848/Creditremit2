import datetime
from django.forms import HiddenInput
from django.core.exceptions import ValidationError
from django import forms
from django.conf import settings
from django.forms.models import ModelForm
from transactions.models import Transaction, Plan, UploadProof,Contact,Rate
from app.models import *
from django.utils import timezone
from datetime import datetime,date
from accounts.models import RecipientAccount 

class RateForm(forms.ModelForm):
    class Meta:
        model = Rate
        fields = '__all__'
        exclude = ('currency','timestamp',)

class ContactForm(forms.ModelForm):
    class Meta:
        model = Contact
        fields = ['name', 'email', 'subject', 'message']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Your Name'}),
            'email': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Your Email'}),
            'subject': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'subject'}),
            'message': forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Your Message'}),
        }



class UploadProofForm(forms.ModelForm):
    class Meta():
        model = UploadProof
        fields = '__all__'
        exclude = ('user',)

class DepositApplicationForm(forms.ModelForm):
    class Meta():
        model = Transaction
        fields = ('plan','amount','recbank')
        exclude = ('user','modified','payment','session_hash','stage','services','address','account','balance_after_transaction','transaction_type','timestamp','endtimestamp','approved',)
    def __init__(self,*args,**kwargs):
        self.user = kwargs.pop('user',None)
        super(DepositApplicationForm, self).__init__(*args,**kwargs)
        self.fields['recbank'].queryset = RecipientAccount.objects.filter(user=self.user)
        
    def clean(self):
        plan = Plan.objects.get(id=1)
        plan2 = Plan.objects.get(id=2)
        account_number = RecipientAccount.objects.filter(country=1)
        account_number2 = RecipientAccount.objects.filter(country=2)
        accountpicked = self.cleaned_data.get("recbank")
        planpicked = self.cleaned_data.get("plan")
        if planpicked == plan and accountpicked == account_number:
            raise ValidationError("Account number picked is not suitable for the CAD Denomination. Create one or select another account that is CAD")
        elif planpicked == plan2 and accountpicked == account_number:
            raise ValidationError("Account number picked is not suitable for the CAD Denomination. Create one or select another account that is CAD")
        else:
            pass

class BaseApplicationForm(forms.ModelForm):
    class Meta():
        model = Transaction
        fields = ('payment','amount','plan')
        exclude = ('user','modified','session_hash','stage','services','address','account','balance_after_transaction','transaction_type','timestamp','endtimestamp','approved',)
    def clean_amount(self):
        plan1 = Plan.objects.get(id=1)
        plan2 = Plan.objects.get(id=2)
        plan3 = Plan.objects.get(id=3)
        plan4 = Plan.objects.get(id=4)
        plan5 = Plan.objects.get(id=5)
        plans = self.cleaned_data.get('plan')
        
        amount = self.cleaned_data.get('amount')
        if plans == plan1:
            min_deposit_amount = 200
            max_deposit_amount = 3999
            if amount < min_deposit_amount:
                raise forms.ValidationError(
                    f'You need to deposit between ${min_deposit_amount} to ${max_deposit_amount} for BASIC plan,please pick another plan for amount below or above ${amount}'
                    )
            if amount > max_deposit_amount:
                raise forms.ValidationError(
                    f'You need to deposit between ${min_deposit_amount} to ${max_deposit_amount} for BASIC plan,please pick another plan for amount below or above ${amount}'
                    )
            return amount
        elif plans == plan2:
            min_deposit_amount = 4000
            max_deposit_amount = 14999
            if amount < min_deposit_amount:
                raise forms.ValidationError(
                    f'You need to deposit between ${min_deposit_amount} to ${max_deposit_amount} for EDGE plan,please pick another plan for amount below or above ${amount}'
                    )
            if amount > max_deposit_amount:
                raise forms.ValidationError(
                    f'You need to deposit between ${min_deposit_amount} to ${max_deposit_amount} for EDGE plan,please pick another plan for amount below or above ${amount}'
                    )
            return amount
        elif plans == plan3:
            min_deposit_amount = 15000
            max_deposit_amount = 39999
            if amount < min_deposit_amount:
                raise forms.ValidationError(
                    f'You need to deposit between ${min_deposit_amount} to ${max_deposit_amount} for SILVER plan,please pick another plan for amount below or above ${amount}'
                    )
            if amount > max_deposit_amount:
                raise forms.ValidationError(
                    f'You need to deposit between ${min_deposit_amount} to ${max_deposit_amount} for SILVER plan,please pick another plan for amount below or above ${amount}'
                    )
            return amount
        elif plans == plan4:
            min_deposit_amount = 40000
            max_deposit_amount = 114999
            if amount < min_deposit_amount:
                raise forms.ValidationError(
                    f'You need to deposit between ${min_deposit_amount} to ${max_deposit_amount} for GOLD plan,please pick another plan for amount below or above ${amount}'
                    )
            if amount > max_deposit_amount:
                raise forms.ValidationError(
                    f'You need to deposit between ${min_deposit_amount} to ${max_deposit_amount} for GOLD plan,please pick another plan for amount below ${amount}'
                    )
            return amount
        elif plans == plan5:
            min_deposit_amount = 150000
            max_deposit_amount = 100000000000000000000
            if amount < min_deposit_amount:
                raise forms.ValidationError(
                    f'You need to deposit between ${min_deposit_amount} to ${max_deposit_amount} for GOLD plan,please pick another plan for amount below or above ${amount}'
                    )
            if amount > max_deposit_amount:
                raise forms.ValidationError(
                    f'You need to deposit between ${min_deposit_amount} to ${max_deposit_amount} for GOLD plan,please pick another plan for amount below ${amount}'
                    )
            return amount
        else:
            raise forms.ValidationError(f'You need to deposit between ${min_deposit_amount} to ${max_deposit_amount} ')
    

    

    class Media:
        css = {
            "all": ("core/style.css",)
        }


class TransactionForm(forms.ModelForm):

    class Meta:
        model = Transaction
        fields = [
            'amount',
            'transaction_type'
        ]

    def __init__(self, *args, **kwargs):
        self.account = kwargs.pop('account')
        super().__init__(*args, **kwargs)

        self.fields['transaction_type'].disabled = True
        self.fields['transaction_type'].widget = forms.HiddenInput()

    def save(self, commit=True):
        self.instance.account = self.account
        self.instance.balance_after_transaction = self.account.balance
        return super().save()


class TransactionForm2(forms.ModelForm):

    class Meta:
        model = Transaction
        fields = [
            'withdrawal',
            'amount',
            'address',
            'transaction_type'
        ]

    def __init__(self, *args, **kwargs):
        # student = Beneficiary.objects.get(account=self.account)
        self.account = kwargs.pop('account')
        super().__init__(*args, **kwargs)

        self.fields['transaction_type'].disabled = True
        self.fields['transaction_type'].widget = forms.HiddenInput()

    def save(self, commit=True):
        self.instance.account = self.account
        self.instance.balance_after_transaction = self.account.balance
        return super().save()


class DepositForm(TransactionForm):

    def clean_amount(self):
        min_deposit_amount = settings.MINIMUM_DEPOSIT_AMOUNT
        amount = self.cleaned_data.get('amount')
        plan = self.cleaned_data.get('plan')
        if plan=='BASIC':
            min_deposit_amount = 300
            maximum_deposit_amount = 999
            if amount < min_deposit_amount and amount > maximum_deposit_amount:
                raise forms.ValidationError(
                f'You need to deposit between ${min_deposit_amount} to ${maximum_deposit_amount} '
                )

            return amount


class WithdrawForm(TransactionForm2):

    def clean_amount(self):
        account = self.account
        min_withdraw_amount = settings.MINIMUM_WITHDRAWAL_AMOUNT
        max_withdraw_amount = settings.MAXIMUM_WITHDRAWAL_AMOUNT
        balance = account.newamount
        newamount = account.newamount
        end = account.interest_start_date
        now2 = timezone.now().date()
        now = date.today()

        amount = self.cleaned_data.get('amount')
        
        if end is None:
            raise forms.ValidationError(f'Invalid')

        elif now < end:
            raise forms.ValidationError(f'You cannot withdraw until end of contract({end})')
            
        elif amount < min_withdraw_amount:
            raise forms.ValidationError(
                    f'Minimum withdrawal per transaction is $ {min_withdraw_amount}'
                )

        elif amount > max_withdraw_amount:
            raise forms.ValidationError(
                f'Maximum withdrawal per transaction is $ {max_withdraw_amount}'
            )

        elif amount > newamount:
            raise forms.ValidationError(
                f'Insufficient Balance! You have ${newamount} in your account. '
                'You can not withdraw more than your account balance'
            )

        return amount



class TransactionDateRangeForm(forms.Form):
    daterange = forms.CharField(required=False)

    def clean_daterange(self):
        daterange = self.cleaned_data.get("daterange")
        print(daterange)

        try:
            daterange = daterange.split(' - ')
            print(daterange)
            if len(daterange) == 2:
                for date in daterange:
                    datetime.datetime.strptime(date, '%Y-%m-%d')
                return daterange
            else:
                raise forms.ValidationError("Please select a date range.")
        except (ValueError, AttributeError):
            raise forms.ValidationError("Invalid date range")
                
class TransactionForm3(forms.ModelForm):
    
    class Meta:
        model = Transaction
        fields = [
            'plan',
            'amount',
            'transaction_type'
        ]

    def __init__(self, *args, **kwargs):
        # student = Beneficiary.objects.get(account=self.account)
        self.account = kwargs.pop('account')
        super().__init__(*args, **kwargs)

        self.fields['transaction_type'].disabled = True
        self.fields['transaction_type'].widget = forms.HiddenInput()

    def save(self, commit=True):
        self.instance.account = self.account
        self.instance.balance_after_transaction = self.account.balance
        return super().save()

class ReinvestForm(TransactionForm3):

    def clean_amount(self):
        account = self.account
        min_deposit_amount = settings.MINIMUM_DEPOSIT_AMOUNT
        amount = self.cleaned_data.get('amount')
        balance = account.balance
        
        plan1 = Plan.objects.get(id=1)
        plan2 = Plan.objects.get(id=2)
        plan3 = Plan.objects.get(id=3)
        plan4 = Plan.objects.get(id=4)
        plan5 = Plan.objects.get(id=5)
        plans = self.cleaned_data.get('plan')
        
        amount = self.cleaned_data.get('amount')
        if amount > balance and amount > account.newamount:
            raise forms.ValidationError(
                f'Insufficient Balance! You have #{balance} in your account. '
                'Please deposit to invest'
            )
        elif plans == plan1:
            min_deposit_amount = 200
            max_deposit_amount = 3999
            if amount < min_deposit_amount:
                raise forms.ValidationError(
                    f'You need to deposit between ${min_deposit_amount} to ${max_deposit_amount} for BASIC plan,please pick another plan for amount below or above ${amount}'
                    )
            if amount > max_deposit_amount:
                raise forms.ValidationError(
                    f'You need to deposit between ${min_deposit_amount} to ${max_deposit_amount} for BASIC plan,please pick another plan for amount below or above ${amount}'
                    )
            return amount
        elif plans == plan2:
            min_deposit_amount = 4000
            max_deposit_amount = 14999
            if amount < min_deposit_amount:
                raise forms.ValidationError(
                    f'You need to deposit between ${min_deposit_amount} to ${max_deposit_amount} for EDGE plan,please pick another plan for amount below or above ${amount}'
                    )
            if amount > max_deposit_amount:
                raise forms.ValidationError(
                    f'You need to deposit between ${min_deposit_amount} to ${max_deposit_amount} for EDGE plan,please pick another plan for amount below or above ${amount}'
                    )
            return amount
        elif plans == plan3:
            min_deposit_amount = 15000
            max_deposit_amount = 39999
            if amount < min_deposit_amount:
                raise forms.ValidationError(
                    f'You need to deposit between ${min_deposit_amount} to ${max_deposit_amount} for SILVER plan,please pick another plan for amount below or above ${amount}'
                    )
            if amount > max_deposit_amount:
                raise forms.ValidationError(
                    f'You need to deposit between ${min_deposit_amount} to ${max_deposit_amount} for SILVER plan,please pick another plan for amount below or above ${amount}'
                    )
            return amount
        elif plans == plan4:
            min_deposit_amount = 40000
            max_deposit_amount = 114999
            if amount < min_deposit_amount:
                raise forms.ValidationError(
                    f'You need to deposit between ${min_deposit_amount} to ${max_deposit_amount} for GOLD plan,please pick another plan for amount below or above ${amount}'
                    )
            if amount > max_deposit_amount:
                raise forms.ValidationError(
                    f'You need to deposit between ${min_deposit_amount} to ${max_deposit_amount} for GOLD plan,please pick another plan for amount below ${amount}'
                    )
            return amount
        elif plans == plan5:
            min_deposit_amount = 150000
            max_deposit_amount = 1000000000000000
            if amount < min_deposit_amount:
                raise forms.ValidationError(
                    f'You need to deposit between ${min_deposit_amount} to ${max_deposit_amount} for SILVER plan,please pick another plan for amount below or above ${amount}'
                    )
            if amount > max_deposit_amount:
                raise forms.ValidationError(
                    f'You need to deposit between ${min_deposit_amount} to ${max_deposit_amount} for SILVER plan,please pick another plan for amount below or above ${amount}'
                    )
            return amount
        elif amount < min_deposit_amount:
            raise forms.ValidationError(
                f'You need to deposit at least #{min_deposit_amount}'
            )
        else:
            raise forms.ValidationError(f'You need to deposit between ${min_deposit_amount} to ')
        return amount