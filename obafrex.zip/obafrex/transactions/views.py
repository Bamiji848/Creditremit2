from datetime import timedelta
from django.shortcuts import redirect, render
from django.views.decorators.http import require_POST
from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.urls import reverse_lazy
from django.utils import timezone
from django.views.generic import CreateView, ListView
from django.contrib.sites.shortcuts import get_current_site
from django.template.loader import render_to_string
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.utils.encoding import force_bytes, force_text
from django.core.mail import EmailMessage
from transactions.constants import DEPOSIT, WITHDRAWAL, TRANSFER,INVEST
from transactions.forms import (
    DepositForm,
    TransactionDateRangeForm,
    WithdrawForm
)
from transactions.models import *
from transactions.forms import *
from app.models import *
from django.urls import reverse
from django.shortcuts import get_object_or_404
from django.http import Http404, HttpResponse, HttpResponseRedirect
from app.forms import *
from djpjax import PJAXResponseMixin
import datetime
import pytz
from django.views.generic import FormView, TemplateView, ListView
from transactions import constants
from django.forms import modelform_factory
from .multiforms import MultiFormsView


def contact(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            sender_name = form.cleaned_data['name']
            sender_email = form.cleaned_data['email']
            sender_subject = form.cleaned_data['subject']
            message = form.cleaned_data['message']
            email_msg = EmailMessage(subject=f"{sender_name}" 'from obafrex contact page' f"{sender_subject}", body=message, from_email='support@obafrexchange.com',to=['support@obafrexchange.com'], headers={'Reply-To': sender_email})
            email_msg.send()
            form = ContactForm()
    else:
        form = ContactForm()
    return render(request, 'app/contact.html', {'form': form,})


class TransactionRepostView(LoginRequiredMixin, ListView):
    template_name = 'core/transactions.html'
    model = Transaction
    form_data = {}

    def get(self, request, *args, **kwargs):
        form = TransactionDateRangeForm(request.GET or None)
        if form.is_valid():
            self.form_data = form.cleaned_data

        return super().get(request, *args, **kwargs)

    def get_queryset(self):
        queryset = super().get_queryset().filter(
            account=self.request.user.account
        )

        daterange = self.form_data.get("daterange")

        if daterange:
            queryset = queryset.filter(timestamp__date__range=daterange)

        return queryset.distinct()

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context.update({
            'account': self.request.user.account,
            'objectlength':Transaction.objects.filter(user=self.request.user).count(),
            'form': TransactionDateRangeForm(self.request.GET or None)
        })

        return context


class TransactionCreateMixin(LoginRequiredMixin, CreateView):
    template_name = 'registration/deposit.html'
    model = Transaction
    title = ''
    success_url = reverse_lazy('transactions:message')

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs.update({
            'account': self.request.user.account
        })
        return kwargs

    def get_context_data(self, **kwargs):
        user = self.request.user
        account = self.request.user.account
        context = super().get_context_data(**kwargs)
        context.update({
            'title': self.title,
            'account': self.request.user.account,
            'plan':Plan.objects.all(),
            't_length': Transaction.objects.filter(account=account),
        })

        return context

class TransactionCreateMixin2(LoginRequiredMixin, CreateView):
    template_name = 'core/invest-money.html'
    model = Transaction
    title = ''
    success_url = reverse_lazy('transactions:message')

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs.update({
            'account': self.request.user.account
        })
        return kwargs



class DepositMoneyView(PJAXResponseMixin, TransactionCreateMixin):
    form_class = DepositForm
    title = 'Add Money to Your Wallet'

    def get_initial(self):
        initial = {'transaction_type': DEPOSIT}
        return initial

    def form_valid(self, form):
        amount = form.cleaned_data.get('amount')
        account = self.request.user.account
        t_length = Transaction.objects.filter(account=account)
        user = self.request.user
        # student = Student.objects.filter(user=user)
        obj = form.save(commit=False)
        obj.save()
        return redirect(reverse('transactions:depositcontinue', args=[obj.id]))
        
        return super().form_valid(form)


def get_job_application_from_hash(session_hash):
    # Find and return an unexpired, not-yet-completed JobApplication
    # with a matching session_hash, or None if no such object exists.
    now = datetime.datetime.utcnow().replace(tzinfo=pytz.UTC)
    max_age = 60 * 60 * 24 * 7 * 2  # Or make this a setting in "settings.py"
    exclude_before = now - datetime.timedelta(seconds=max_age)
    return Transaction.objects.filter(
        session_hash=session_hash,
        modified__gte=exclude_before
    ).exclude(
        stage=constants.COMPLETE
    ).first()


class DepositView(LoginRequiredMixin, FormView):
    template_name = 'registration/deposit.html'
    job_application = None
    form_class = None
    title = 'Add Money to Your Wallet'

    def get_initial(self):
        initial = {'transaction_type': DEPOSIT}
        return initial
        
    def get_context_data(self,*args,**kwargs):
        context = super(DepositView, self).get_context_data(*args,**kwargs)
        context['acc'] = RecipientAccount.objects.filter(user=self.request.user).count()
        return context

    def dispatch(self, request, *args, **kwargs):
        session_hash = request.session.get("session_hash", None)
        # Get the job application for this session. It could be None.
        self.job_application = get_job_application_from_hash(session_hash)
        # Attach the request to "self" so "form_valid()" can access it below.
        self.request = request
        return super().dispatch(request, *args, **kwargs)
        
  
    def form_valid(self, form):
        # This data is valid, so set this form's session hash in the session.
        # self.request.session["session_hash"] = form.instance.session_hash
        # current_stage = form.cleaned_data.get("stage")
        account = self.request.user.account
        # Get the next stage after this one.
        # new_stage = constants.STAGE_ORDER[constants.STAGE_ORDER.index(
            # current_stage)+1]
        # form.instance.stage = new_stage
        amount = form.cleaned_data.get("amount")
        obj = form.save(commit=False)
        obj.account = account
        obj.balance_after_transaction = account.balance + obj.balance_after_transaction
        obj.transaction_type = DEPOSIT
        obj.paid = True
        obj.user = self.request.user
        obj.endtimestamp = timezone.now()
        obj.save()
        plan1 = Plan.objects.get(id=1)
        plan2 = Plan.objects.get(id=2)
        rater = Rate.objects.get(id=1)
        ratetoday = plan1.rate
        title = 'Add Money to Your Wallet'
        # if new_stage == constants.COMPLETE:
        if obj.plan_id == 1:
            new = amount*plan1.rate.rate
            obj.bonus = new
            obj.save()
        elif obj.plan_id == 2:
            new = amount/plan2.rate.rate
            obj.bonus = new
            obj.save()
        try:
            user = self.request.user
            name = user.name
            amount = obj.amount
            email = user.email
            con = obj.plan
            time = obj.endtimestamp
            current_site = get_current_site(self.request)
            mail_subject = 'Obafrex(Deposit Notification)'
            message = render_to_string(
                'adminpage/email-trans.html', {'email': email, 'amount': amount, 'domain': current_site.domain,'name':name,'con':con,'time':time})
            to_email = user.email
            email = EmailMessage(mail_subject, message, to=[to_email])
            email.content_subtype = 'html'
            email.send()
            messages.success(self.request,'Transaction successful. Awaiting Confirmation')
            return redirect(reverse("transactions:upload_proof", args=[obj.id]))
        except User.DoesNotExist:
            Http404('The page you are accessing does not exist')
            # new_stage = constants.STAGE_3
            # return redirect(reverse("transactions:success", args=[obj.id]))
        return redirect(reverse("transactions:job_application"), {'title': title})

    def get_form_class(self):
        # If we found a job application that matches the session hash, look at
        # its "stage" attribute to decide which stage of the application we're
        # on. Otherwise assume we're on stage 1.
        # stage = self.job_application.stage if self.job_application else constants.STAGE_1
        # Get the form fields appropriate to that stage.
        # fields = Transaction.get_fields_by_stage(stage)
        # Use those fields to dynamically create a form with "modelform_factory"
        return modelform_factory(Transaction, DepositApplicationForm)

    def get_form_kwargs(self):
        # Make sure Django uses the same JobApplication instance we've already been
        # working on. Otherwise it will instantiate a new one after every submit.
        kwargs = super().get_form_kwargs()
        kwargs["instance"] = self.job_application
        kwargs['user'] = self.request.user
        return kwargs
        
        
def upload_proof(request,id):
    account = request.user.account
    amountgen = get_object_or_404(Transaction, account=account, id=id)
    amount = amountgen.amount
    if request.method == 'POST':
        form = UploadProofForm(request.POST,request.FILES)
        if form.is_valid():
            user = request.user
            dt = form.save(commit=False)
            dt.user = user
            dt.save()
            messages.success(request,'Successful Upload, Awaiting Confirmation')
            return redirect('transactions:message')
    form = UploadProofForm()
    return render(request,'app/upload-proof.html',context={'form':form,'amount':amount,'amountgen':amountgen})

def confirm_deposit(request,id):
    try:
        user = request.user
        account = user.account
        amountgen = get_object_or_404(Transaction, account=account, id=id)
        amountgen.approved = True
        amount = amountgen.bonus
        account.balance += amount
        account.amount = amountgen.amount
        now = timezone.now()
        account.initial_deposit_date = now
        account.save(
            update_fields=[
                'initial_deposit_date',
                'balance',
                'amount'
            ]
        )
        messages.success(request,f'Transaction {id} approved')
        return redirect('admin:index')
    except Transaction.DoesNotExist:
        Http404('The page you are accessing does not exist')

def depositcontinue(request):
    plan = Plan.objects.all()
    return render(request, 'core/estateDeposit.html', {'plan': plan})


def btc(request, id):
    user = request.user
    account = request.user.account
    amountgen = get_object_or_404(Transaction, account=account, id=id)
    amount = amountgen.amount
    if request.method == 'POST':
        amountgen.paid = True
        amountgen.save()
        return redirect('transactions:success', id=id)
    return render(request, 'core/btc.html', {'amountgen': amountgen})

def success(request, id):
    try:
        user = request.user
        account = request.user.account
        amountgen = get_object_or_404(Transaction, account=account, id=id)
        amount = amountgen.amount
        amountgen.paid = True
        now = timezone.now()
        endtime = (now + timedelta(days=7))
        amountgen.endtimestamp = endtime
        amountgen.save()

        if amountgen.paid == True:
            account = request.user.account
            amountgen = get_object_or_404(Transaction, id=id)
            amountgen.approved = True
            amount = amountgen.amount
            account.balance += amount
            account.amount = amount
            account.amount = amount
            now = timezone.now()
            account.initial_deposit_date = now
            account.interest_start_date = (now + timedelta(days=7))
            account.save(
                update_fields=[
                    'initial_deposit_date',
                    'balance',
                    'amount',
                    'interest_start_date'
                ]
            )
            if amount >= 200 and amount <= 3999:
                interest = amount*Decimal(0.42)
                account.interestday1 = amount*Decimal(0.063)
                account.interestday2 = amount * \
                    Decimal(0.063)+account.interestday1
                account.interestday3 = amount * \
                    Decimal(0.063)+account.interestday2
                account.interestday4 = amount * \
                    Decimal(0.063)+account.interestday3
                account.interestday5 = amount * \
                    Decimal(0.063)+account.interestday4
                account.interestday6 = amount * \
                    Decimal(0.063)+account.interestday5
                account.interestday7 = amount * \
                    Decimal(0.042)+account.interestday6
                newamount = amount+interest
                account.newamount += newamount
                account.interest += interest
                account.amount = amount
                now = timezone.now()
                account.initial_deposit_date = now
                account.interest_start_date = (now + timedelta(days=40))
                account.save(
                    update_fields=[
                        'interest',
                        'interestday1',
                        'interestday2',
                        'interestday3',
                        'interestday4',
                        'interestday5',
                        'interestday6',
                        'interestday7',
                        'newamount',
                        'interest_start_date',
                        'initial_deposit_date'
                    ]
                )
            elif amount >= 4000 and amount <= 14999:
                interest = amount*Decimal(0.453)
                account.interestday1 = amount*Decimal(0.091)
                account.interestday2 = amount * \
                    Decimal(0.091)+account.interestday1
                account.interestday3 = amount * \
                    Decimal(0.091)+account.interestday2
                account.interestday4 = amount * \
                    Decimal(0.091)+account.interestday3
                account.interestday5 = amount * \
                    Decimal(0.091)+account.interestday4
                newamount = amount+interest
                account.newamount += newamount
                account.interest += interest
                account.amount = amount
                now = timezone.now()
                account.initial_deposit_date = now
                account.interest_start_date = (now + timedelta(days=30))
                account.save(
                    update_fields=[
                        'interest',
                        'interestday1',
                        'interestday2',
                        'interestday3',
                        'interestday4',
                        'interestday5',
                        'newamount',
                        'interest_start_date',
                        'initial_deposit_date'
                    ]
                )
            elif amount >= 15000 and amount <= 39999:
                interest = amount*Decimal(0.515)
                account.interestday1 = amount*Decimal(0.124)
                account.interestday2 = amount * \
                    Decimal(0.124)+account.interestday1
                account.interestday3 = amount * \
                    Decimal(0.124)+account.interestday2
                account.interestday4 = amount * \
                    Decimal(0.124)+account.interestday3
                account.interestday5 = amount * \
                    Decimal(0.0206)+account.interestday4
                newamount = amount+interest
                account.newamount += newamount
                account.interest += interest
                account.amount = amount
                now = timezone.now()
                account.initial_deposit_date = now
                account.interest_start_date = (now + timedelta(days=25))
                account.save(
                    update_fields=[
                        'interest',
                        'interestday1',
                        'interestday2',
                        'interestday3',
                        'interestday4',
                        'interestday5',
                        'newamount',
                        'interest_start_date',
                        'initial_deposit_date'
                    ]
                )
            elif amount >= 40000 and amount <= 114999:
                # now = timezone.now()
                # account.interest_start_date = (now + timedelta(days=1))
                interest = amount*Decimal(0.384)
                account.interestday1 = amount*Decimal(0.154)
                account.interestday2 = amount * \
                    Decimal(0.154)+account.interestday1
                account.interestday3 = amount * \
                    Decimal(0.077)+account.interestday2
                newamount = amount+interest
                account.newamount += newamount
                account.interest += interest
                account.amount = amount
                now = timezone.now()
                account.initial_deposit_date = now
                account.interest_start_date = (now + timedelta(days=15))
                account.save(
                    update_fields=[
                        'interest',
                        'interestday1',
                        'interestday2',
                        'interestday3',
                        'newamount',
                        'interest_start_date',
                        'initial_deposit_date'
                    ]
                )
            elif amount >= 114999:
                    # now = timezone.now()
                # account.interest_start_date = (now + timedelta(days=1))
                interest = amount*Decimal(0.36)
                account.interestday1 = amount*Decimal(0.216)
                account.interestday2 = amount * \
                    Decimal(0.144)+account.interestday1
                newamount = amount+interest
                account.newamount += newamount
                account.interest += interest
                account.amount = amount
                now = timezone.now()
                account.initial_deposit_date = now
                account.interest_start_date = (now + timedelta(days=10))
                account.save(
                    update_fields=[
                        'interest',
                        'interestday1',
                        'interestday2',
                        'newamount',
                        'interest_start_date',
                        'initial_deposit_date'
                    ]
                )
            else:
                return HttpResponse('Invalid!')
            if account.initial_deposit_date:
                now = timezone.now()
                account.initial_deposit_date = now
                account.interest_start_date = (now + timedelta(days=7))
                account.save(
                    update_fields=[
                        'initial_deposit_date',
                        'interest_start_date',
                    ]
                )
            # return render(self.request, 'transactions/pay.html', {'student': student, 'amount': amount, 'account': account, 't_length': t_length})
        messages.success(request,'Transaction completed. Awaiting confirmation')
        return redirect('transactions:upload_proof')
    except Transaction.DoesNotExist:
        Http404('The page you are accessing does not exist')
    # return render(request, 'transactions/success.html', {'amountgen': amountgen})

def confirm(request, id):
    try:
        amountgen = get_object_or_404(Transaction, paid=True, id=id)
        account = amountgen.account
        amount = amountgen.amount
        amountgen.approved = True
        amountgen.save()
        account = amountgen.account
        amountgen = get_object_or_404(Transaction, paid=True, id=id)
        amount = amountgen.amount
        account.balance += amount
        current_site = get_current_site(request)
        mail_subject = 'GroupForte(Referral Bonus Notification)'
        message = render_to_string('core/referralbonus.html', {'bonugetter':amountgen.referralbonus,'email': amountgen.user,'pay':amountgen.payment,'amount': amount, 'domain': current_site.domain})
        to_email = amountgen.referralbonus
        email1 = EmailMessage(mail_subject, message, to=[to_email])
        email1.content_subtype = 'html'
        email1.send()
        account.amount = amount
        now = timezone.now()
        account.initial_deposit_date = now
        account.interest_start_date = (now + timedelta(days=7))
        account.save(
            update_fields=[
                'initial_deposit_date',
                'balance',
                'amount',
                'interest_start_date'
            ]
        )
        current_site1 = get_current_site(request)
        mail_subject1 = 'GroupForte(Deposit Approved Successfully)'
        message1 = render_to_string('core/email.html', {'email': amountgen.user,'pay':amountgen.payment,'amount': amount, 'domain': current_site1.domain})
        to_email1 = amountgen.user
        email1 = EmailMessage(mail_subject1, message1, to=[to_email1])
        email1.content_subtype = 'html'
        email1.send()
    
        if amount >= 200 and amount <= 3999:
            account.amount = amount
            now = timezone.now()
            account.initial_deposit_date = now
            account.interest_start_date = (now + timedelta(days=40))
            interest = amount*Decimal(0.42)
            account.interestday1 = amount*Decimal(0.063)
            account.interestday2 = amount * Decimal(0.063)+account.interestday1
            account.interestday3 = amount * Decimal(0.063)+account.interestday2
            account.interestday4 = amount * Decimal(0.063)+account.interestday3
            account.interestday5 = amount * Decimal(0.063)+account.interestday4
            account.interestday6 = amount * Decimal(0.063)+account.interestday5
            account.interestday7 = amount * Decimal(0.042)+account.interestday6
            newamount = amount+interest
            account.newamount += newamount
            account.interest += interest
            account.save(
                update_fields=[
                    'interest',
                    'interestday1',
                    'interestday2',
                    'interestday3',
                    'interestday4',
                    'interestday5',
                    'interestday6',
                    'interestday7',
                    'newamount',
                    'interest_start_date',
                    'initial_deposit_date'
                ]
            )
        elif amount >= 4000 and amount <= 14999:
            interest = amount*Decimal(0.453)
            account.interestday1 = amount*Decimal(0.091)
            account.interestday2 = amount * Decimal(0.091)+account.interestday1
            account.interestday3 = amount * Decimal(0.091)+account.interestday2
            account.interestday4 = amount * Decimal(0.091)+account.interestday3
            account.interestday5 = amount * Decimal(0.091)+account.interestday4
            newamount = amount+interest
            account.newamount += newamount
            account.interest += interest
            account.amount = amount
            now = timezone.now()
            account.initial_deposit_date = now
            account.interest_start_date = (now + timedelta(days=30))
            account.save(
                update_fields=[
                    'interest',
                    'interestday1',
                    'interestday2',
                    'interestday3',
                    'interestday4',
                    'interestday5',
                    'newamount',
                    'interest_start_date',
                    'initial_deposit_date'
                ]
            )
        elif amount >= 15000 and amount <= 39999:
            interest = amount*Decimal(0.259)
            account.interestday1 = amount*Decimal(0.124)
            account.interestday2 = amount * Decimal(0.124)+account.interestday1
            account.interestday3 = amount * Decimal(0.124)+account.interestday2
            account.interestday4 = amount * Decimal(0.124)+account.interestday3
            account.interestday5 = amount * Decimal(0.021)+account.interestday4
            newamount = amount+interest
            account.newamount += newamount
            account.interest += interest
            account.amount = amount
            now = timezone.now()
            account.initial_deposit_date = now
            account.interest_start_date = (now + timedelta(days=25))
            account.save(
                update_fields=[
                    'interest',
                    'interestday1',
                    'interestday2',
                    'interestday3',
                    'interestday4',
                    'interestday5',
                    'newamount',
                    'interest_start_date',
                    'initial_deposit_date'
                ]
            )
        elif amount >= 40000 and amount <= 114999:
            # now = timezone.now()
            # account.interest_start_date = (now + timedelta(days=1))
            interest = amount*Decimal(0.384)
            account.interestday1 = amount*Decimal(0.154)
            account.interestday2 = amount * Decimal(0.154)+account.interestday1
            account.interestday3 = amount * Decimal(0.077)+account.interestday2
            newamount = amount+interest
            account.newamount += newamount
            account.interest += interest
            account.amount = amount
            now = timezone.now()
            account.initial_deposit_date = now
            account.interest_start_date = (now + timedelta(days=15))
            account.save(
                update_fields=[
                    'interest',
                    'interestday1',
                    'interestday2',
                    'interestday3',
                    'newamount',
                    'interest_start_date',
                    'initial_deposit_date'
                ]
            )
        elif amount >= 150000:
            # now = timezone.now()
            # account.interest_start_date = (now + timedelta(days=1))
            interest = amount*Decimal(0.36)
            account.interestday1 = amount*Decimal(0.216)
            account.interestday2 = amount * Decimal(0.144)+account.interestday1
            newamount = amount+interest
            account.newamount += newamount
            account.interest += interest
            account.amount = amount
            now = timezone.now()
            account.initial_deposit_date = now
            account.interest_start_date = (now + timedelta(days=10))
            account.save(
                update_fields=[
                    'interest',
                    'interestday1',
                    'interestday2',
                    'newamount',
                    'interest_start_date',
                    'initial_deposit_date'
                ]
            )
        else:
            return HttpResponse('Invalid!')
        if not account.initial_deposit_date:
            now = timezone.now()
            account.initial_deposit_date = now
            account.interest_start_date = (now + timedelta(days=7))
            account.save(
                update_fields=[
                    'initial_deposit_date',
                    'interest_start_date',
                ]
            )
        # return render(self.request, 'transactions/pay.html', {'student': student, 'amount': amount, 'account': account, 't_length': t_length)

        messages.success(request,f'Transaction {id} approved')
        return redirect('balmadmin:deposit_manage')
    except Transaction.DoesNotExist:
        Http404('The page you are accessing does not exist')
    # return render(request, 'transactions/success.html', {'amountgen': amountgen})
        

def invest(request):
    return render(request, 'core/invest.html')


def investpro(request):
    return render(request, 'core/investDeposit.html')


def message(request):
    user = request.user
    account = request.user.account
    t_length = Transaction.objects.filter(account=account)
    t_new = Transaction.objects.latest('timestamp')
    context = {
        'account': account,
        't_length': t_length,
        't_new':t_new
    }
    return render(request, 'app/success1.html', context)


class WithdrawMoneyView(TransactionCreateMixin):
    form_class = WithdrawForm
    title = 'Withdraw Money'

    def get_initial(self):
        initial = {'transaction_type': WITHDRAWAL}
        return initial

    def form_valid(self, form):
        amount = form.cleaned_data.get('amount')
    
        if self.request.user.account.newamount == 0:
            self.request.user.account.balance -= form.cleaned_data.get('amount')
            self.request.user.account.newamount = 0
            self.request.user.account.save(update_fields=['newamount'])
            self.request.user.account.save(update_fields=['balance'])
        elif self.request.user.account.balance == 0:
            self.request.user.account.balance = 0
            self.request.user.account.newamount -= form.cleaned_data.get('amount')
            self.request.user.account.save(update_fields=['newamount'])
            self.request.user.account.save(update_fields=['balance'])
        else:
            self.request.user.account.balance -= form.cleaned_data.get('amount')
            self.request.user.account.newamount -= form.cleaned_data.get('amount')
            self.request.user.account.save(update_fields=['newamount'])
            self.request.user.account.save(update_fields=['balance'])
        try:
            user = self.request.user
            amount = form.cleaned_data.get('amount')
            email = user.email
            current_site = get_current_site(self.request)
            mail_subject = 'MinoCapital(Withdrawal Notification)'
            message = render_to_string(
                'core/wemail.html', {'email': email, 'amount': amount, 'domain': current_site.domain, })
            to_email = user.email
            email = EmailMessage(mail_subject, message, to=[to_email])
            email.content_subtype = 'html'
            email.send()
        except User.DoesNotExist:
            Http404('The page you are accessing does not exist')
            # new_stage = constants.STAGE_3
        messages.success(
            self.request,
            f'Successfully withdrawn #{amount} from your account'
        )

        return super().form_valid(form)
    
def withconfirm(request,id):
    try:
        amountgen = get_object_or_404(Transaction,id=id)
        # account = amountgen.account
        user = amountgen.account
        amount = amountgen.amount
        amountgen.approved = True
        amountgen.paid = True
        amountgen.save()
        current_site = get_current_site(request)
        mail_subject = 'GroupForte(Withdrawal Approved Successfully)'
        message = render_to_string('core/witapproval.html', {'email': amountgen.user,'pay':amountgen.withdrawal,'amount': amount, 'domain': current_site.domain})
        to_email = user
        email = EmailMessage(mail_subject, message, to=[to_email])
        email.content_subtype = 'html'
        email.send()
        messages.success(request,f'Transaction {id} approved')
        return redirect('admin:index')
    except Transaction.DoesNotExist:
        Http404('The page you are accessing does not exist')
    # return render(request, 'transactions/success.html', {'amountgen': amountgen})

class ReinvestView(TransactionCreateMixin2):
    form_class = ReinvestForm
    title = 'Reinvest'

    def get_initial(self):
        initial = {'transaction_type': INVEST}
        return initial

    def form_valid(self, form, **kwargs):
        amount = form.cleaned_data.get('amount')
        account = self.request.user.account

        # self.request.user.account.newamount -= form.cleaned_data.get('amount')
        self.request.user.account.balance -= form.cleaned_data.get('amount')
        # self.request.user.account.save(update_fields=['newamount'])
        self.request.user.account.save(update_fields=['balance'])
        obj = form.save(commit=False)
        # obj.account = account
        # obj.balance_after_transaction = account.balance + obj.balance_after_transaction
        obj.transaction_type = INVEST
        obj.user = self.request.user
        obj.paid = True
        obj.approved = True
        now = timezone.now()
        endtime = (now + timedelta(days=7))
        obj.endtimestamp = endtime
        obj.save()
        try:
            account.initial_deposit_date = now
            account.interest_start_date = (now + timedelta(days=7))
            account.balance = obj.balance_after_transaction
            account.amount = amount
            account.save(
                update_fields=[
                    'initial_deposit_date',
                    'interest_start_date',
                    'balance',
                    'amount',
                ]
            )
            if amount >= 200 and amount <= 3999:
                interest = amount*Decimal(0.42)
                account.interestday1 = amount*Decimal(0.063)
                account.interestday2 = amount * Decimal(0.063)+account.interestday1
                account.interestday3 = amount * Decimal(0.063)+account.interestday2
                account.interestday4 = amount * Decimal(0.063)+account.interestday3
                account.interestday5 = amount * Decimal(0.063)+account.interestday4
                account.interestday6 = amount * Decimal(0.063)+account.interestday5
                account.interestday7 = amount * Decimal(0.042)+account.interestday6
                newamount = amount+interest
                account.newamount += newamount
                account.interest += interest
                now = timezone.now()
                account.initial_deposit_date = now
                account.interest_start_date = (now + timedelta(days=40))
                account.save(
                    update_fields=[
                        'balance',
                        'interest',
                        'interestday1',
                        'interestday2',
                        'interestday3',
                        'interestday4',
                        'interestday5',
                        'interestday6',
                        'interestday7',
                        'newamount',
                        'interest_start_date',
                        'initial_deposit_date'
                    ]
                )
            elif amount >= 4000 and amount <= 14999:
                interest = amount*Decimal(0.453)
                account.interestday1 = amount*Decimal(0.091)
                account.interestday2 = amount * Decimal(0.091)+account.interestday1
                account.interestday3 = amount * Decimal(0.091)+account.interestday2
                account.interestday4 = amount * Decimal(0.091)+account.interestday3
                account.interestday5 = amount * Decimal(0.091)+account.interestday4
                newamount = amount+interest
                account.newamount += newamount
                account.interest += interest
                account.interest_start_date = (now + timedelta(days=30))
                account.save(
                    update_fields=[
                        'interest',
                        'interestday1',
                        'interestday2',
                        'interestday3',
                        'interestday4',
                        'interestday5',
                        'newamount',
                        'interest_start_date'
                    ]
                )
            elif amount >= 15000 and amount <= 39999:
                interest = amount*Decimal(0.259)
                account.interestday1 = amount*Decimal(0.124)
                account.interestday2 = amount * Decimal(0.124)+account.interestday1
                account.interestday3 = amount * Decimal(0.124)+account.interestday2
                account.interestday4 = amount * Decimal(0.124)+account.interestday3
                account.interestday5 = amount * Decimal(0.021)+account.interestday4
                newamount = amount+interest
                account.newamount += newamount
                account.interest += interest
                account.interest_start_date = (now + timedelta(days=25))
                account.save(
                    update_fields=[
                        'interest',
                        'interestday1',
                        'interestday2',
                        'interestday3',
                        'interestday4',
                        'interestday5',
                        'newamount',
                        'interest_start_date'
                    ]
                )
            elif amount >= 40000 and amount <= 114999:
                interest = amount*Decimal(0.384)
                account.interestday1 = amount*Decimal(0.154)
                account.interestday2 = amount * Decimal(0.154)+account.interestday1
                account.interestday3 = amount * Decimal(0.077)+account.interestday2
                newamount = amount+interest
                newamount = amount+interest
                account.newamount += newamount
                account.interest += interest
                account.interest_start_date = (now + timedelta(days=15))
                account.save(
                    update_fields=[
                        'interest',
                        'interestday1',
                        'interestday2',
                        'interestday3',
                        'newamount',
                        'interest_start_date'
                    ]
                )
            elif amount > 114999:
                interest = amount*Decimal(0.36)
                account.interestday1 = amount*Decimal(0.216)
                account.interestday2 = amount * Decimal(0.144)+account.interestday1
                newamount = amount+interest
                newamount = amount+interest
                account.newamount += newamount
                account.interest += interest
                account.interest_start_date = (now + timedelta(days=10))
                account.save(
                    update_fields=[
                        'interest',
                        'interestday1',
                        'interestday2',
                        'interestday3',
                        'newamount',
                        'interest_start_date'
                    ]
                )
            elif now >= account.interest_start_date:
                newvalue = account.amount+account.interest
                account.balance += newvalue
                account.newamount += newvalue
                account.save(
                    update_fields=[
                        'balance',
                        'newamount'
                    ]
                )
            else:
                return HttpResponse('Invalid!')
            if not account.initial_deposit_date:
                now = timezone.now()
                account.initial_deposit_date = now
                account.interest_start_date = (now + timedelta(days=7))
                account.save(
                    update_fields=[
                        'initial_deposit_date',
                        'interest_start_date',
                    ]
                )
            return redirect('transactions:message')
        except User.DoesNotExist:
            Http404('The page you are accessing does not exist')

        return super().form_valid(form)


def success3(request, id):
    try:
        account = request.user.account
        now = timezone.now()
        amountgen = get_object_or_404(
            Transaction, paid=True, id=id)
        
        endtime = (now + timedelta(days=7))
        amountgen.endtimestamp = endtime
        amount = amountgen.amount
        amountgen.user=request.user
        amountgen.approved = True
        amountgen.save()
        account.initial_deposit_date = now
        account.interest_start_date = (now + timedelta(days=7))
        account.balance = amountgen.balance_after_transaction
        account.save(
            update_fields=[
                'initial_deposit_date',
                'interest_start_date',
                'balance',
            ]
        )
        if amount >= 200 and amount <= 3999:
            interest = amount*Decimal(0.42)
            account.interestday1 = amount*Decimal(0.063)
            account.interestday2 = amount * Decimal(0.063)+account.interestday1
            account.interestday3 = amount * Decimal(0.063)+account.interestday2
            account.interestday4 = amount * Decimal(0.063)+account.interestday3
            account.interestday5 = amount * Decimal(0.063)+account.interestday4
            account.interestday6 = amount * Decimal(0.063)+account.interestday5
            account.interestday7 = amount * Decimal(0.042)+account.interestday6
            newamount = amount+interest
            account.newamount += newamount
            account.interest += interest
            now = timezone.now()
            account.initial_deposit_date = now
            account.interest_start_date = (now + timedelta(days=40))
            account.save(
                update_fields=[
                    'balance',
                    'interest',
                    'interestday1',
                    'interestday2',
                    'interestday3',
                    'interestday4',
                    'interestday5',
                    'interestday6',
                    'interestday7',
                    'newamount',
                    'interest_start_date',
                    'initial_deposit_date'
                ]
            )
        elif amount >= 4000 and amount <= 14999:
            interest = amount*Decimal(0.453)
            account.interestday1 = amount*Decimal(0.091)
            account.interestday2 = amount * Decimal(0.091)+account.interestday1
            account.interestday3 = amount * Decimal(0.091)+account.interestday2
            account.interestday4 = amount * Decimal(0.091)+account.interestday3
            account.interestday5 = amount * Decimal(0.091)+account.interestday4
            newamount = amount+interest
            account.newamount += newamount
            account.interest += interest
            account.interest_start_date = (now + timedelta(days=30))
            account.save(
                update_fields=[
                    'interest',
                    'interestday1',
                    'interestday2',
                    'interestday3',
                    'interestday4',
                    'interestday5',
                    'newamount',
                    'interest_start_date'
                ]
            )
        elif amount >= 15000 and amount <= 39999:
            interest = amount*Decimal(0.259)
            account.interestday1 = amount*Decimal(0.124)
            account.interestday2 = amount * Decimal(0.124)+account.interestday1
            account.interestday3 = amount * Decimal(0.124)+account.interestday2
            account.interestday4 = amount * Decimal(0.124)+account.interestday3
            account.interestday5 = amount * Decimal(0.021)+account.interestday4
            newamount = amount+interest
            account.newamount += newamount
            account.interest += interest
            account.interest_start_date = (now + timedelta(days=25))
            account.save(
                update_fields=[
                    'interest',
                    'interestday1',
                    'interestday2',
                    'interestday3',
                    'interestday4',
                    'interestday5',
                    'newamount',
                    'interest_start_date'
                ]
            )
        elif amount >= 40000 and amount <= 114999:
            interest = amount*Decimal(0.384)
            account.interestday1 = amount*Decimal(0.154)
            account.interestday2 = amount * Decimal(0.154)+account.interestday1
            account.interestday3 = amount * Decimal(0.077)+account.interestday2
            newamount = amount+interest
            newamount = amount+interest
            account.newamount += newamount
            account.interest += interest
            account.interest_start_date = (now + timedelta(days=15))
            account.save(
                update_fields=[
                    'interest',
                    'interestday1',
                    'interestday2',
                    'interestday3',
                    'newamount',
                    'interest_start_date'
                ]
            )
        elif amount > 114999:
            interest = amount*Decimal(0.36)
            account.interestday1 = amount*Decimal(0.216)
            account.interestday2 = amount * Decimal(0.144)+account.interestday1
            newamount = amount+interest
            newamount = amount+interest
            account.newamount += newamount
            account.interest += interest
            account.interest_start_date = (now + timedelta(days=10))
            account.save(
                update_fields=[
                    'interest',
                    'interestday1',
                    'interestday2',
                    'interestday3',
                    'newamount',
                    'interest_start_date'
                ]
            )
        elif now >= account.interest_start_date:
            newvalue = account.amount+account.interest
            account.balance += newvalue
            account.newamount += newvalue
            account.save(
                update_fields=[
                    'balance',
                    'newamount'
                ]
            )
        else:
            return HttpResponse('Invalid!')
        if not account.initial_deposit_date:
            now = timezone.now()
            account.initial_deposit_date = now
            account.interest_start_date = (now + timedelta(days=7))
            account.save(
                update_fields=[
                    'initial_deposit_date',
                    'interest_start_date',
                ]
            )
        return redirect('transactions:message')
    except User.DoesNotExist:
        Http404('The page you are accessing does not exist')
    # return redirect(reverse("transactions:success3", args=[form.id]))
    
def withdraw_bonus(request):
    account = request.user.account
    try:
        account.balance += account.referral_bonus
        account.newamount += account.referral_bonus
        account.referral_bonus = 0
        account.save(
                update_fields=[
                    'referral_bonus',
                    'balance',
                    'newamount',
                ]
            )
        return redirect('ref')
    except User.DoesNotExist:
        Http404('The page you are accessing does not exist')
        
