from django.urls import path
from .views import DepositMoneyView, WithdrawMoneyView, TransactionRepostView,DepositView
from . import views
from .views import *
app_name = 'transactions'


urlpatterns = [
    path("registration/", DepositView.as_view(), name="job_application"),
    path("upload-proof/<int:id>/", views.upload_proof, name="upload_proof"),
    path("btc/<int:id>", views.btc, name="btc"),
    path('contac-us/',views.contact,name="contact"),
    path("deposit-money-proceed/", views.depositcontinue, name="depositcontinue"),
    path("report/", TransactionRepostView.as_view(), name="transaction_report"),
    path("withdraw-money/", WithdrawMoneyView.as_view(), name="withdraw_money"),
    path('success/<int:id>/', views.success, name='success'),
    path('success3/<int:id>/', views.success, name='success3'),
    path('withconfirm/<int:id>/', views.withconfirm, name='withconfirm'),
    path("reinvest/", ReinvestView.as_view(), name="reinvest"),
    path('confirm/<int:id>/', views.confirm, name='confirm'),
    path('confirm_deposit/<int:id>/', views.confirm_deposit, name='confirm_deposit'),
    path('withdraw-bonus/',views.withdraw_bonus,name='withdraw_bonus'),
    path('message/', views.message, name='message'),
    path('invest/', views.invest, name='invest'),
    path('investpro/', views.investpro, name='investpro'),
]
