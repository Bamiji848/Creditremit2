from distutils.command.upload import upload
import sys
import random
import hashlib
from django.db import models
from transactions import constants
from .constants import TRANSACTION_TYPE_CHOICES
from accounts.models import UserBankAccount,User,RecipientAccount
from django.utils.translation import ugettext_lazy as _

class UploadProof(models.Model):
    user = models.CharField(max_length=400, verbose_name='user',null=True,blank=True)
    upload_proof = models.ImageField(upload_to='images')
    
    def __str__(self):
        return self.user

class Services(models.Model):
    services = models.CharField(max_length=400, verbose_name='Services')

    def __str__(self):
        return self.services

class Payment(models.Model):
    paymentprovider = models.CharField(max_length=400, verbose_name='Payment')
    walletaddress = models.CharField(max_length=400, verbose_name='Wallet Address')
    barcode = models.ImageField(upload_to='images')

    def __str__(self):
        return self.paymentprovider

class Withdrawal(models.Model):
    paymentprovider = models.CharField(max_length=400, verbose_name='Payment')
    walletaddress = models.CharField(max_length=400, verbose_name='Wallet Address')

    def __str__(self):
        return self.paymentprovider
    
class Rate(models.Model):
    currency = models.CharField(max_length=3000,null=True,blank=True)
    rate = models.DecimalField(
        decimal_places=7,
        max_digits=12,
        null=True
    )
    timestamp = models.DateField(auto_now_add=True)
    
    
    def __str__(self):
        return self.currency
    
class Plan(models.Model):
    plan = models.CharField(max_length=400, verbose_name='Plan')
    minimum = models.IntegerField(verbose_name='Minimum')
    maximum = models.IntegerField(verbose_name='Maximum')
    rate = models.ForeignKey(Rate,on_delete=models.CASCADE,verbose_name='Rate Today',null=True,blank='True')

    def __str__(self):
        return self.plan

def create_session_hash():
    hash = hashlib.sha1()
    hash.update(str(random.randint(0, sys.maxsize)).encode('utf-8'))
    return hash.hexdigest()

class Transaction(models.Model):
    recbank = models.ForeignKey(RecipientAccount,on_delete=models.CASCADE,verbose_name="Recipient Bank")
    referralbonus = models.ForeignKey(
        User, on_delete=models.CASCADE,
        null=True,related_name='bonus'
    )
    user = models.ForeignKey(
        User, on_delete=models.CASCADE,
        null=True
    )
    bonus = models.DecimalField(
        decimal_places=2,
        max_digits=12,
        null=True
    )
    modified = models.DateTimeField(auto_now=True)
    session_hash = models.CharField(max_length=40, unique=True)
    stage = models.CharField(max_length=10, default=constants.STAGE_1)
    services = models.ForeignKey(
        Services, on_delete=models.CASCADE,null=True,blank=True
    )
    plan = models.ForeignKey(
        Plan, on_delete=models.CASCADE,
        null=True,verbose_name='From (What Currency?)'
    )
    payment = models.ForeignKey(
        Payment, on_delete=models.CASCADE,
        null=True,verbose_name='Select Gateway'
    )
    withdrawal = models.ForeignKey(
        Withdrawal, on_delete=models.CASCADE,
        null=True,blank=True,verbose_name='Select Gateway'
    )
    address = models.CharField(max_length=3000,blank=True,null=True,verbose_name='Wallet address')
    account = models.ForeignKey(
        UserBankAccount,
        related_name='transactions',
        on_delete=models.CASCADE,
        null=True
    )
    amount = models.DecimalField(
        decimal_places=2,
        max_digits=12,
        null=True
    )
    balance_after_transaction = models.DecimalField(
        decimal_places=2,
        max_digits=12,
        null=True,
        default=0
    )
    transaction_type = models.PositiveSmallIntegerField(
        choices=TRANSACTION_TYPE_CHOICES,
        null=True
    )
    timestamp = models.DateField(auto_now_add=True)
    endtimestamp = models.DateField(
        null=True, blank=True,
        help_text=(
            'The month number that transaction will expire'
        )
    )
    paid = models.BooleanField(
        default=False, verbose_name="Tick this box if you have made payment")
    approved = models.BooleanField(
        default=False, verbose_name="Approved")

    hidden_fields = ['stage']
    required_fields = ['services','paid']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if not self.session_hash:
            while True:
                session_hash = create_session_hash()
                if Transaction.objects.filter(session_hash=session_hash).count() == 0:
                    self.session_hash = session_hash
                    break

    @staticmethod
    def get_fields_by_stage(stage):
        fields = ['stage']  # Must always be present
        if stage == constants.STAGE_1:
            fields.extend(['services'])
        elif stage == constants.STAGE_2:
            fields.extend(['plan','amount'])
        elif stage == constants.STAGE_3:
            fields.extend(['payment','paid'])
        return fields

    class Meta:
        ordering = ['-timestamp']


class Contact(models.Model):
    name = models.CharField(max_length=100)
    subject = models.CharField(max_length=300)
    email = models.EmailField()
    message = models.TextField()

    def __str__(self):
        return self.name
