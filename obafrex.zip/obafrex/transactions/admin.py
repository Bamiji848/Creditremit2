from django.contrib import admin
from django.shortcuts import redirect
from django.urls import path
from transactions.models import Payment, Services, Plan, Transaction, Withdrawal,Rate,UploadProof
import csv
import datetime
from django.http import HttpResponse
from django.utils.safestring import mark_safe
from transactions import views
from django.utils.html import format_html
from django.urls import reverse

def export_to_csv(modeladmin, request, queryset):
    opts = modeladmin.model._meta
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment;'\
        'filename={}.csv'.format(opts.verbose_name)
    writer = csv.writer(response)
    fields = [field for field in opts.get_fields() if not field.many_to_many
              and not field.one_to_many]
    # Write a first row with header information
    writer.writerow([field.verbose_name for field in fields])
    # Write data rows
    for obj in queryset:
        data_row = []
        for field in fields:
            value = getattr(obj, field.name)
            if isinstance(value, datetime.datetime):
                value = value.strftime('%d/%m/%Y')
            data_row.append(value)
        writer.writerow(data_row)
    return response


export_to_csv.short_description = 'Export to CSV'


# admin.site.register(Transaction)
class TransactionAdmin(admin.ModelAdmin):
    list_display = ['account', 'amount', 'transaction_type',
                    'timestamp', 'paid', 'approved', 'approveconfirm']
    list_filter = ['paid', 'approved']
    actions = [export_to_csv]

    def approveconfirm(self, obj):
        if obj.transaction_type == 1:
            return mark_safe(f'<a href="http://127.0.0.1:8000/transactions/confirm_deposit/{obj.id}">Confirm Deposit</a>')
        elif obj.transaction_type == 2:
            return mark_safe(f'<a href="http://127.0.0.1:8000/transactions/withconfirm/{obj.id}">Confirm Withdrawal</a>')
        else:
            pass
         
admin.site.register(Transaction, TransactionAdmin)
admin.site.register(Services)
admin.site.register(Plan)
admin.site.register(Payment)
admin.site.register(Withdrawal)
admin.site.register(Rate)
admin.site.register(UploadProof)