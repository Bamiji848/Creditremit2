from distutils.command.upload import upload
from django import forms
from django.core import validators
from django.conf import settings
from django.forms.fields import DateTimeField
from django.forms.widgets import DateTimeBaseInput, DateTimeInput
from . models import *
from adminpage.models import *
from django.contrib.auth.forms import(
    PasswordResetForm, SetPasswordForm, PasswordChangeForm,
    UserChangeForm, UserCreationForm)
from datetime import date


class DateInput(forms.DateInput):
    input_type = 'date'


class DateRangeForm(forms.Form):
    start_date = forms.DateTimeField(
        label='From:', widget=DateInput(attrs={'class': 'form-control'}))
    end_date = forms.DateTimeField(
        label='To:', widget=DateInput(attrs={'class': 'form-control'}))


