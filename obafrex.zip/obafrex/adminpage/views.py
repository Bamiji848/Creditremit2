from django.views.generic import View
from datetime import datetime
from email import message
from urllib import response
from django.shortcuts import render, redirect
from adminpage.models import *
from . models import *
from accounts.models import *
from django.core.paginator import Paginator, EmptyPage,\
    PageNotAnInteger
from adminpage.forms import *
from django.db.models import Q
from django.contrib.auth import login, logout, authenticate
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404
from django.http import Http404, HttpResponse, HttpResponseRedirect
# Create your views here.
from django.shortcuts import render
from django.shortcuts import render
from django.http import HttpResponse
from transactions.models import Transaction,Rate
from transactions.constants import DEPOSIT, WITHDRAWAL, TRANSFER,INVEST
from transactions.forms import (
    DepositForm,
    TransactionDateRangeForm,
    WithdrawForm,
    RateForm,
)
from django.contrib.sites.shortcuts import get_current_site
from django.template.loader import render_to_string
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.utils.encoding import force_bytes, force_text
from django.core.mail import EmailMessage

# Create your views here.

def login_view(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        user = authenticate(request, email=email, password=password)
        if user is not None:
            if user.is_staff == True:
                login(request, user)
                return redirect('adminpage:dashboard')
            else:
                messages.error(request, 'Invalid login')
        else:
            messages.error(request, 'Email and Password does not match')
    return render(request, 'adminpage/login.html')

@login_required(login_url='/dashboard/')    
def rates(request):
    rates = Rate.objects.all()
    context = {
        'rates':rates
    }
    return render(request,'adminpage/rates.html',context)

@login_required(login_url='/dashboard/')
def edit_rate(request, id):
    post = get_object_or_404(Rate,id=id)
    
    if request.method == 'GET':
        context = {'form':RateForm(instance=post), 'id':id}
        return render(request,'adminpage/rate_form.html',context)
        
    elif request.method == 'POST':
        form = RateForm(request.POST, instance=post)
        if form.is_valid():
            form.save()
            messages.success(request,'The rate has been updated successfully.')
            return redirect('adminpage:rates')
        else:
            messages.error(request,'Please correct the following errors:')
            return render(request,'adminpage/rate_form.html',{'form':form})
            
@login_required(login_url='/dashboard/')
def active_users(request):
    users_active = User.objects.filter(is_active=True,kycverified=True)
    context = {
        'users_active':users_active,
    }
    return render(request,'adminpage/users-active.html',context)
    
@login_required(login_url='/dashboard/')
def inactive_users(request):
    users_inactive = User.objects.filter(kycverified=False)
    context = {
        'users_inactive':users_inactive,
    }
    return render(request,'adminpage/users-inactive.html',context)
    
@login_required(login_url='/dashboard/')
def bank_users(request):
    users_bank = RecipientAccount.objects.all().order_by('user')
    context = {
        'users_bank':users_bank,
    }
    return render(request,'adminpage/users-bank.html',context)
    
@login_required(login_url='/dashboard/')    
def trans_p(request):
    trans = Transaction.objects.filter(paid=True,approved=True)
    context = {
        'trans':trans,
    }
    return render(request,'adminpage/processed-transactions.html',context)
    
@login_required(login_url='/dashboard/')    
def trans_pend(request):
    trans = Transaction.objects.filter(paid=True,approved=False)
    context = {
        'trans':trans,
    }
    return render(request,'adminpage/pending.html',context)
    
@login_required(login_url='/dashboard/')    
def trans_approve(request,id):
    trans = Transaction.objects.get(paid=True,id=id)
    trans.approved = True
    trans.save()
    try:
        user = trans.user.name
        amount = trans.amount
        email = trans.user.email
        con = trans.plan
        got = trans.bonus
        bank = trans.recbank
        current_site = get_current_site(request)
        mail_subject = 'Obafrex(Deposit Notification)'
        message = render_to_string('adminpage/approval-email.html', {'email': email, 'user':user,'amount': amount, 'domain': current_site.domain,'con':con,'got':got,'bank':bank})
        to_email = email
        email = EmailMessage(mail_subject, message, to=[to_email])
        email.content_subtype = 'html'
        email.send()
    except Transaction.DoesNotExist:
        Http404('The page you are accessing does not exist')
    messages.success(request,"Transaction has been approved. Notification sent to user")
    return redirect('adminpage:trans_pend')
    
@login_required(login_url='/dashboard/')    
def users_kyc(request):
    users_kyc = User.objects.filter(kycverified=False)
    users_kyc2 = User.objects.filter(kycverified=True)
    context = {
        'users_kyc':users_kyc,
        'users_kyc2':users_kyc2,
    }
    return render(request,'adminpage/users-kyc.html',context)

@login_required(login_url='/dashboard/')
def dashboard(request):
    user = request.user
    account = user.account
    userl = User.objects.filter(is_active=True).count()
    dep = Transaction.objects.filter(account=account,paid=True,approved=True,transaction_type=DEPOSIT,plan_id=1)
    depn = Transaction.objects.filter(account=account,paid=True,approved=True,transaction_type=DEPOSIT,plan_id=2)
    depl = Transaction.objects.filter(account=account,paid=True,approved=False,transaction_type=DEPOSIT).count()
    dept = sum(dep.values_list('amount',flat=True))
    depnt = sum(depn.values_list('amount',flat=True))
    context = {
        'dep':dep,
        'dept':dept,
        'depnt':depnt,
        'depl':depl,
        'userl':userl,
    }
    return render(request, 'adminpage/dashboard.html',context)


@login_required(login_url='/dashboard/')
def logout_user(request):
    logout(request)
    return redirect('adminpage:login_view')





