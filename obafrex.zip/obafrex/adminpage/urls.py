from django.urls import path
from . import views
from django.conf.urls import url

app_name = "adminpage"

urlpatterns = [
    path('', views.login_view, name='login_view'),
    path('logout-page/', views.logout_user, name='logout_user'),
    path('dashboard/', views.dashboard, name="dashboard"),
    path('rates/',views.rates,name='rates'),
    path('rate/edit/<int:id>/', views.edit_rate, name='rate-edit'),
    path('active-users/',views.active_users,name='active_users'),
    path('inactive-users/',views.inactive_users,name='inactive_users'),
    path('users-bank/',views.bank_users,name='bank_users'),
    path('users-kyc/',views.users_kyc,name='users_kyc'),
    path('processed-transactions/',views.trans_p, name='trans_p'),
    path('pending-transactions/',views.trans_pend, name='trans_pend'),
    path('trans_approve/<int:id>/', views.trans_approve, name='trans_approve'),
]
