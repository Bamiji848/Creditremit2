$(document).ready(function() {	
	var currFund = $('#main_selCurrencyFrom').val(), rate = 0;
	updateCurrencySel(currFund);
	rate = getRate($("#hndConvALL input[type='hidden']"),currFund,$('#main_inpAmount').val());
	updateAmount(currFund,rate,$('#main_inpAmount').val());
	
	$('#main_selCurrencyFrom').on('change', function() {
		$('#main_hndCurrency').val(this.value);
		updateCurrencySel(this.value);
		console.log(this.value);
		var currFund = this.value, amount = $("#main_inpAmount").val(), rate = getRate($("#hndConvALL input[type='hidden']"), this.value, amount);
		$('#main_hndRate').val(rate);
		updateAmount(currFund,rate,amount);
	});
	
	$('#main_inpAmount').bind('keyup keydown keypress change paste', function () {
		var ctrlId = this.id;
		var currFund = $('#main_selCurrencyFrom').val(), rate = 0;
		if(ctrlId=="main_inpAmount"){
			if (isNaN($(this).val())) {
				$(this).val("1");
				rate = getRate($("#hndConvALL input[type='hidden']"),currFund,1);
				updateAmount(currFund,rate,$(this).val());
			}
			else{
				rate = getRate($("#hndConvALL input[type='hidden']"),currFund,$(this).val());
				updateAmount(currFund,rate,$(this).val());
			}
		}
	});
	
	$(".canvas-mail").canvas_mail("info", "mpexchange.ca");	
});

$(".phone-val").spamguard({ protect: "telephone" });

function updateCurrencySel(selcurr)
{ 
	if (selcurr=="CAD"){	
		$('#main_selCurrencyTo').empty();
		$('#main_selCurrencyTo').append('<option selected="selected" value="NGN">NGN</option>');
		$('select').niceSelect('update');
	}
	else if (selcurr=="NGN"){
		$('#main_selCurrencyTo').empty();
		$('#main_selCurrencyTo').append('<option selected="selected" value="CAD">CAD</option>');
		$('select').niceSelect('update');
	} 
}

function mirrorCurrency(fromselcurr, toselcurr){
	return toselcurr;
}

function convertCurr(curr)
{
	var toReturn = "";
	if(curr=="CAD")
	{
		toReturn = "NGN2CAD";
	}
	else if(curr=="NGN")
	{
		toReturn = "CAD2NGN";
	}
	return toReturn;
}

function detectFloat(currency){ 
    var temp = currency.replace(/[^0-9.-]+/g,""); 
    return parseFloat(temp);                
} 

function formatNumber(num) {
  return num.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,')
}

function randomString(len, charSet) {
	charSet = charSet || 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
	var randomString = '';
	for (var i = 0; i < len; i++) {
		var randomPoz = Math.floor(Math.random() * charSet.length);
		randomString += charSet.substring(randomPoz,randomPoz+1);
	}
	return randomString;
}

function getRate(item,curr,amt){
	var hndConvALL = item.val(); amt = detectFloat(amt);
	//var JSONConvALL = $.parseJSON(hndConvALL);
	var JSONConvALL = allcurrencies;
	curr = convertCurr(curr);
	//console.log(curr);
	var ttAmnt = [];
	$.each(JSONConvALL, function (key, value) {
		if(value.currency_desc==curr && (amt >= value.amount_from && amt <= value.amount_to)){
			ttAmnt = value;
		}
	});
	return ttAmnt.rate;
}

function currencyChargeRule(currFund,amt,bank,chgnAmt)
{
	var stampDuty = 0, interBankchrg = 0;var costChrg = [];
	if(currFund=="NGN" && bank!="GTB"){
		if(amt < 5000)
		{
			interBankchrg = 10.75;
		}
		else if (amt >= 5000 && amt <= 50000){
			interBankchrg = 26.88;
		}
		else if (amt > 50000){
			interBankchrg = 53.75;
		}
		costChrg.push({"charge":"Interbank Charge plus VAT", "amt":interBankchrg});
	}
	else if(currFund=="CAD"){
		if (chgnAmt > 10000){
			stampDuty = 50.00;
			costChrg.push({"charge":"Stamp Duty", "amt":stampDuty});
		}
	}
	console.log(currFund+"-"+bank+"-"+chgnAmt+"-"+amt);
	console.log(JSON.stringify(costChrg));
	/*
	if (amt > 10000){
		stampDuty = 50.00;
		costChrg.push({"charge":"Stamp Duty", "amt":stampDuty});
	}*/
	return costChrg;
}

function CalculateToTalCharge(chrgs)
{
	var ttAmnt = 0;
	$.each(chrgs, function (key, value) {
		ttAmnt += chrgs[key].amt;
	});
	return ttAmnt;
}

function updateAmount(currFund,rate,amt){
	var value = 0, totalAmt = 0, amtFund = 0, fx = 2, totalCharges = 0, totalAllAmt = 0; var chrges; var currenci = "", theWords = "";
	amt = detectFloat(amt);
	
	if(currFund=="CAD")
	{
		currFund = mirrorCurrency(currFund,"NGN");	
		value = parseFloat(rate);
		currenci = "#";
		amtFund = parseFloat(amt);	
		totalAmt = value * parseFloat(amt);
		//console.log("Total => "+totalAmt+"-"+value+"-"+amt);
		//theWords = moneyToWord(totalAmt,"Naira","Kobo");
		fx = 2;
		
		chrges = currencyChargeRule(currFund,amt,"GTB",totalAmt);
		totalCharges = CalculateToTalCharge(chrges);
		totalAllAmt = totalAmt + totalCharges;
	}
	else if(currFund=="NGN"){
		currFund = mirrorCurrency(currFund,"CAD");	
		value = parseFloat(rate);
		currenci = "$";
		amtFund =  parseFloat(amt)/value;
		totalAmt = parseFloat(amt)/value;
		totalAllAmt = totalAmt;
		//theWords = moneyToWord(totalAmt,"Dollar","Cent");
		fx = 2;
		
		
	}
	
	
	//console.log(totalAmt);
	//console.log(currenci+formatNumber(parseFloat(totalAmt).toFixed(2)));
	//Display identity upload	
	if(parseFloat(amt)<1){
		//$('#lblResult').show();
		//$('#lblResult').html("<h4>Result:</h4>Please enter amount to buy.")
	}
	else if(rate=="0" || typeof rate == "undefined"){
		//$('#lblResult').show();
		//$('#lblResult').html("<h4>Result:</h4>Please choose the currency option.")
	}
	else if (totalAmt>0) {
		$('#spExchRate').html("<strong>"+currenci+rate.toFixed(2)+"</strong> Exchange Rate");
		$('#spTransFee').html("<strong>"+currenci+totalCharges.toFixed(2)+"</strong> Bank Charges");
		$('#spTotal').html("Total amount you will get <strong>"+currenci+formatNumber(totalAllAmt.toFixed(2))+"</strong> (Bank charges may apply).");
		//$('#spTotal').html("Total amount you will get <strong>"+currenci+formatNumber(totalAllAmt.toFixed(2))+"</strong> (Interbank charges and stamp duty may apply).");
		
		$('#main_inpAmountExch').val(formatNumber(parseFloat(totalAmt).toFixed(2)));
		//$('#lblResult').show();
		//$('#lblResult').html("<h4>Result:</h4>You will pay "+currenci+formatNumber(parseFloat(totalAmt).toFixed(2))+".<br/><br/>Click <a href='http://maplepayexch.crestcrm.com/sign-in.aspx'>here</a> to continue with your purchase");
	}
}

