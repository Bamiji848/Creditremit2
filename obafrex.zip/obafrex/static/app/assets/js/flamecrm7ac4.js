﻿
	var crypto = window.crypto || window.msCrypto || null; // IE11 fix

	var Guid = Guid || (function () {

		var EMPTY = '00000000-0000-0000-0000-000000000000';

		var _padLeft = function (paddingString, width, replacementChar) {
			return paddingString.length >= width ? paddingString : _padLeft(replacementChar + paddingString, width, replacementChar || ' ');
		};

		var _s4 = function (number) {
			var hexadecimalResult = number.toString(16);
			return _padLeft(hexadecimalResult, 4, '0');
		};

		var _cryptoGuid = function () {
			var buffer = new window.Uint16Array(8);
			window.crypto.getRandomValues(buffer);
			return [_s4(buffer[0]) + _s4(buffer[1]), _s4(buffer[2]), _s4(buffer[3]), _s4(buffer[4]), _s4(buffer[5]) + _s4(buffer[6]) + _s4(buffer[7])].join('-');
		};

		var _guid = function () {
			var currentDateMilliseconds = new Date().getTime();
			return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (currentChar) {
				var randomChar = (currentDateMilliseconds + Math.random() * 16) % 16 | 0;
				currentDateMilliseconds = Math.floor(currentDateMilliseconds / 16);
				return (currentChar === 'x' ? randomChar : (randomChar & 0x7 | 0x8)).toString(16);
			});
		};

		var create = function () {
			var hasCrypto = crypto != 'undefined' && crypto !== null,
				hasRandomValues = typeof (window.crypto.getRandomValues) != 'undefined';
			return (hasCrypto && hasRandomValues) ? _cryptoGuid() : _guid();
		};

		return {
			newGuid: create,
			empty: EMPTY
		};
	})();	
	
	Array.remove = function(array, fromTo, to) {
		var rest = array.slice((to || fromTo) + 1 || array.length);
		array.length = fromTo < 0 ? array.length + fromTo : fromTo;
		return array.push.apply(array, rest);
	};

	function paddString(strValue)	
	{
		var toReturnVal = "";
		if(strValue!=null)
		{
			if(strValue.length==1) toReturnVal = "0000000" + strValue;
			else if(strValue.length==2) toReturnVal = "000000" + strValue;
			else if(strValue.length==3) toReturnVal = "00000" + strValue;
			else if(strValue.length==4) toReturnVal = "0000" + strValue;
			else if(strValue.length==5) toReturnVal = "000" + strValue;
			else if(strValue.length==6) toReturnVal = "000" + strValue;
			else if(strValue.length==7) toReturnVal = "00" + strValue;
			else if(strValue.length==8) toReturnVal = "0" + strValue;
		}
		return toReturnVal;
	}
	
	function ShowSuccessToMain(message) {
		//$alert = $('#MBWrapper1');
		//$alert.removeClass().addClass('MessageBoxInterface');
		$.jAlert({ 
			'title': 'Message', 
			'closeBtn':false,			
			'content': message, 
			'theme': 'dark_blue',
			'btns': [
				{'text':'Close', 'theme':'blue'}
			],
			'onClose': function(alertElem){
				location.href = "https://www.mpexchange.ca/account/user/main.aspx";
		    }
		});
	}
	
	function ShowSuccessToLogin(message) {
		//$alert = $('#MBWrapper1');
		//$alert.removeClass().addClass('MessageBoxInterface');
		$.jAlert({ 
			'title': 'Message', 
			'closeBtn':false,			
			'content': message, 
			'theme': 'dark_blue',
			'btns': [
				{'text':'Close', 'theme':'blue'}
			],
			'onClose': function(alertElem){
				location.href = "login.aspx";
		    }
		});
	}

	function ShowSuccessReload(message) {
		//$alert = $('#MBWrapper1');
		//$alert.removeClass().addClass('MessageBoxInterface');
		$.jAlert({ 
			'title': 'Message', 
			'closeBtn':false,			
			'content': message, 
			'theme': 'dark_blue',
			'btns': [
				{'text':'Close', 'theme':'blue'}
			],
			'onClose': function(alertElem){
				location.href = location.pathname;
		    }
		});
	}
	
	function ShowSuccessContact(message) {
		//$alert = $('#MBWrapper1');
		//$alert.removeClass().addClass('MessageBoxInterface');
		$.jAlert({ 
			'title': 'Message', 
			'content': message, 
			'theme': 'dark_blue',
			'btns': [
				{'text':'Close', 'theme':'blue'}
			],
			'onClose': function(alertElem){
				location.href = location.pathname;
		    }
		});
	}
	
	function ShowSuccess(message) {
		//$alert = $('#MBWrapper1');
		//$alert.removeClass().addClass('MessageBoxInterface');
		$.jAlert({ 'title': 'Message', 'content': message, 'theme': 'dark_blue' });
	}

	function ShowError(message) {
		//$alert = $('#MBWrapper1');
		//$alert.removeClass().addClass('MessageBoxInterface');
		$.jAlert({ 'title': 'Message', 'content': message, 'theme': 'red' });
	}
	
	function ShowInfo(message) {
		//$alert = $('#MBWrapper1');
		//$alert.removeClass().addClass('MessageBoxInterface');
		$.jAlert({ 'title': 'Message', 'content': message, 'theme': 'blue' });
	}
	
	function ShowInfoXp(message) {
		$.jAlert({ 'title': 'Terms and Conditions', 
			'closeBtn':false,
			'content': message, 
			'theme': 'blue', 
			'size': '600px',
			'btns': [
				{'text':'Close', 'theme':'blue'}
			],
			'onClose': function(alertElem){
				if($('.btn_register').length){
					$('.btn_register').prop('disabled', false);
				}
		    }
		});
	}
	
	function ShowInfoXp2(message) {
		$.jAlert({ 'title': 'Terms and Conditions', 
			'closeBtn':false,
			'content': message, 
			'theme': 'blue', 
			'size': '600px',
			'autofocus': 'input[name="email"]',
			'btns': [
				{'text':'Close', 'theme':'blue'}
			],
			'onClose': function(alertElem){
				if($('.btn_register').length){
					//$('.btn_register').prop('disabled', false);
				}
		    }
		});
	}
	
	function ShowWarning(message) {
		//$alert = $('#MBWrapper1');
		//$alert.removeClass().addClass('MessageBoxInterface');
		$.jAlert({ 'title': 'Message', 'content': message, 'theme': 'orange' });
	}
	
	function ShowInfoPwdReset(accesskey) {
		var thekey = accesskey;
		$.jAlert({ 
		    'title': 'Email Confirmation', 
			'closeBtn':false,
			'content': '<div id="LoginForm"><div id="MsgBox"></div><div class="form-group"><label>Enter confirmation code:</label><br><input id="txtConfirmCode" class="form-control" type="text" name="txtConfirmCode"></div></div>', 
			'autofocus': 'input[name="txtConfirmCode"]',
			'theme': 'blue', 
			'size': '300px',
			'blurBackground': true,
			'btns': [
				{'text': 'Submit', 'theme': 'blue', 'closeAlert': false, 'onClick': function(e){
						e.preventDefault();
						var btn = $('#'+this.id),
						alert = btn.parents('.jAlert'),
						form = alert.find('#LoginForm'),
						errorAlert = form.find('#MsgBox'),
						pass = form.find('input[name="txtConfirmCode"]').val(), myaccesskey = "";
						/* Verify required fields, validate data */
						if( typeof pass == 'undefined' || pass == '')
						{
						  errorAlert.html('<div class="alert alert-danger"><strong>Error!</strong> Please enter confirmation code!</div>');
						  return;
						}
						if(pass.length > 0){
							myaccesskey = thekey+'|'+pass;
							var mydata ="";
							//Call Ajax
							try{
								var data = {'d':myaccesskey};
								$.getJSON(getURL("/account/user/useracc.ashx"), data, function(response,status){
									if(status=="success")
									{
										if(response=="success"){
											location.href = location.pathname;
										}
										else{
											errorAlert.html('<div class="alert alert-danger"><strong>Error!</strong> '+response+'</div>');
										}
									}
								})
								.fail(function (xhr, status, error) {
									errorAlert.html('<div class="alert alert-danger"><strong>Error!</strong> Please enter a valid code!</div>');
								}); 
							}
							catch(e)
							{
								errorAlert.html(JSON.stringify(e));
							}
							return;

							/* If it was successful, redirect user */
							//window.location.href = '';
							//return false; 
						}
						else{
							return; 
						}
					}
				}
			]
		});
	}
	
	function getURL(path)
	{
		return window.location.protocol + "//" + window.location.hostname + path;
	}
	
	function getURLwithCallback(url, datas, callBack) 
	{
		$.ajax(
		{
		  type: "GET",
		  url: url,
		  data: datas,
		  async: true,
		  cache: false,
		  success: function(data, textStatus, xhr) 
		  {
			  return callBack(data); 
		  },
		  error: function(xhr, textStatus, errorThrown) 
		  {
			  return "Error: " + errorThrown;
		  }
		})
		
	}
	
	function getURLCallback(url, datas) 
	{
		return $.ajax(
		{
		    type: "GET",
		    url: url,
		    data: datas,
		    async: true,
		    cache: false
		});
		
	}
	
	function callbackError(response)
	{
		//ShowError(JSON.stringify(response));
	}
	
	// clear select options
    function _refreshSelectPicker($obj, str) {
      if (str) {
        $obj.html(str).selectpicker('refresh');
        return;
      }
      $obj.html(' ').selectpicker('refresh');
    }
	
	 // to json
    function _toJson(str) {
      if (str) {
        return JSON.parse(str.replace(/#/g, '"'));
      }
      return false;
    }

    // creat select options
    function _creatOptions(data, optionName, optionValue) {
      if (data && data.length > 0) {
        var options = '';
        for (var index = 0; index < data.length; index++) {
          var name = data[index][optionName];
          options += '<option value="' + data[index][optionValue] + '">' + name + '</option>';
        }
        return options;
      }
    }
	
	function doService(dataReq, url, callback) {                            
			var datax;
			var data = {
				getServ: function (dataReq, url) {
					getWebservice(dataReq, url).done(callback);
					//.error(callbackError);                   
			}
		},defer = $.Deferred();
		defer.promise(data);
		defer.resolve(dataReq, url);
		data.done(function (dataReq, url) {
			data.getServ(dataReq, url);
		});
		//.fail(function(xhr) { alert('error callback for true condition', xhr) });
	}
	
	function getWebservice(dataReq, urlL) {
		urlL = getURL("/account/admin/serv.asmx") + urlL;
		return $.ajax({
			type: "POST",
			url: urlL,
			data: dataReq,
			contentType: "application/json; charset=utf-8",
			dataType: "json"
		});
	}
	
	function doService2(dataReq, url, callback) {                            
			var datax;
			var data = {
				getServ: function (dataReq, url) {
					getWebservice2(dataReq, url).done(callback);
					//.error(callbackError);                   
			}
		},defer = $.Deferred();
		defer.promise(data);
		defer.resolve(dataReq, url);
		data.done(function (dataReq, url) {
			data.getServ(dataReq, url);
		});
		//.fail(function(xhr) { alert('error callback for true condition', xhr) });
	}
	
	function getWebservice2(dataReq, urlL) {
		urlL = getURL("/account/admin/serv.asmx") + urlL;
		return $.ajax({
			type: "POST",
			url: urlL,
			data: dataReq,
			contentType: "application/json; charset=utf-8",
			dataType: "json"
		});
	}
	
	function doService3(options, callback) {  
		var data = {
			getServ: function (options) {
				$.ajax(options).done(callback);                 
			}
		},defer = $.Deferred();
		defer.promise(data);
		defer.resolve(options);
		data.done(function (options) {
			data.getServ(options);
		});
	}
	
	function doServiceX(dataReq, url, callback) {                            
			var datax;
			var data = {
				getServ: function (dataReq, url) {
					getWebservice(dataReq, url).done(callback);
					//.error(callbackError);                   
			}
		},defer = $.Deferred();
		defer.promise(data);
		defer.resolve(dataReq, url);
		data.done(function (dataReq, url) {
			data.getServ(dataReq, url);
		});
		return data;
	}
	
	function createUsername(fullName) {
	   var piece;
	   var size;

	   piece = fullName.split(' ');
	   size = piece.length;
	   var name = piece[size-1].toLowerCase();
	   for (var i = size -2; i > 0; i--) {
		   name = piece[i][0].toLowerCase() + name;
	   }
	   return name;
	}
	
	function doServiceM(dataReq, url, callback) {                            
			var datax;
			var data = {
				getServ: function (dataReq, url) {
					getWebserviceM(dataReq, url).done(callback);
					//.error(callbackError);                   
			}
		},defer = $.Deferred();
		defer.promise(data);
		defer.resolve(dataReq, url);
		data.done(function (dataReq, url) {
			data.getServ(dataReq, url);
		});
		//.fail(function(xhr) { alert('error callback for true condition', xhr) });
	}
	
	function getWebserviceM(dataReq, urlL) {
		urlL = getURL("/check") + urlL;
		return $.ajax({
			type: "POST",
			url: urlL,
			async: true,
			data: dataReq,
			contentType: "application/json; charset=utf-8",
			dataType: "json"
		});
	}
	
	function doServiceK(dataReq, url, callback) {                            
			var data = {
				getServ: function (dataReq, url) {
					getWebserviceK(dataReq, url).done(callback);
					//.error(callbackError);                   
			}
		},defer = $.Deferred();
		defer.promise(data);
		defer.resolve(dataReq, url);
		data.done(function (dataReq, url) {
			data.getServ(dataReq, url);
		});
		return data;
	}
	
	function getWebserviceK(dataReq, urlL) {
		return $.ajax({
		  type: "GET",
		  url: urlL,
		  data: dataReq,
		  async: true,
		  cache: false
		})
	}
	
	function getMyWebServe(urlL)
	{
		urlL = getURL("/check") + urlL;
		$.get(urlL, function(res) {
			alert(res);
		});
	}
	
	function createNewUserName(fullName) {
		var s = fullName.toLowerCase().match(/[a-z]+/g)
		, l = s.length, _s = "", y = -1;
		  do { _s += s[++y][0] } while (_s.length < l -1);
			  return l > 1 ? _s + s[l -1] : fullName;
	}
	
	function getDayNameByNumber(dd) 
	{ 
	   var days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
	   return days[dd]; 
	}

	function getShortDayNameByNumber(dd) 
	{ 
	   var days = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
	   return days[dd]; 
	}

	function getMonthNamebyNumber(mm) 
	{ 
	   var months = new Array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"); 
	   return months[mm]; 
	}

	function getMonthShortNamebyNumber(mm) 
	{ 
	   var months = new Array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"); 
	   return months[mm]; 
	}
	
	function FormatString(val)
	{
		return val.replace("'", "\\'");
	}
	
	/** Formats a value as units, shows 6 decimal places **/
	function FormatUnits(val)
	{
		return parseFloat(val).toFixed(6).toString();
	}

	/** Format string as percent to two decimal places, if not number return 0.00% **/
	function FormatAsPercent(val)
	{
		var ReturnVal = parseFloat(val)
						.toFixed(2);
						
		if(isNaN(ReturnVal))
		{
			ReturnVal = '0.00%';
		}
		else
		{
			ReturnVal = ReturnVal.toString() + '%';
		}
		return ReturnVal;	
	}

	/** Formats a value as currency including decimals, commas and dollar sign **/
	function formatNumberXX(num) {
	  return num.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,')
	}
	
	function formatNumber(n) {
	  // format number 1000000 to 1,234,567
	  return n.toString().replace(/\D/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",")
	}
	
	function FormatAsCurrency(val)
	{
		return '$' + FormatAsDollarValue(val);
	}
	
	function FormatAsCurrencyVal(val,curr)
	{
		return curr + FormatAsDollarValue(val);
	}

	function FormatAsDollarValue(val)
	{
		return parseFloat(val.toString().replace(/,/g, ""))
						.toFixed(2)
						.toString()
						.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
	}
	
	// Only allows the input of number keys, decimal or comma
	function isNumberKey(evt, inclComma)
	{
		var charCode = (evt.which) ? evt.which : evt.keyCode;
		//allow backspace,delete,period,decimal
		if($.inArray(charCode, [8,46,110,190]) !== -1 ||(charCode == 188 && inclComma))
		{
			return true;
		}
		//allow numbers on keyboard, allow numbers on numpad
		if (evt.shiftKey || (charCode < 48 || charCode > 57) && (charCode < 96 || charCode > 105))
		{
			return false;
		}
		return true;
	}
	
	function DisableDivInputs(div){
		div.attr("disabled","disabled");
	}

	function EnableDivInputs(div){
		div.removeAttr("disabled");
	}
	
	function toTitleCase(str)
	{
		return str.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
	}
	
	function ValidateEmail(EmailInput) 
	{
		var strEmail = EmailInput.val().trim();
		var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		return re.test(strEmail);
	}
	
	function ValidateDate(dateElement)
	{
		var ValidDate = true;
		var strDate = dateElement.val().trim();
		
		if (!(/\d{1,2}\/\d{1,2}\/\d{4}/).test(strDate)) {
			ValidDate = false;
		}
		return ValidDate;
	}

	function ValidateNumeric(inputElement)
	{
		var TestValue = inputElement.val().replace(/\,/g, '');
		if(isNaN(TestValue))
		{
			return false;
		}
		else
		{
			return true;
		}
	}
	
	function ValidateRequired(InputBox)
	{
		var TrimmedInput = InputBox.val().trim();
		return TrimmedInput != "";
	}
	
	function clearInputs(div){
		$("#" + div + " :input").each(function(){
			$(this).val('');
		});
		/*$("#" + div + " :select").each(function(){
			$(this).val('');
		});*/
	}
	
	function showloading(divAfter, loadID){
		var loading = '<div id="'+loadID+'" class="overlay"><i class="fa fa-refresh fa-spin"></i></div>';
		$(loading).insertAfter($("#"+divAfter));
	}		
	
	function hideloading(loadID){
		$("#"+loadID).remove();
	}	
	
	function hideme(loadCls){
		$("."+loadCls).hide();
	}

	function showme(loadCls){
		$("."+loadCls).show();
	}	
	
	String.prototype.embraceWith = function(tag) {
				return "<" + tag + ">" + this + "</" + tag + ">";
	};
	String.prototype.embraceWithCol = function(tag) {
				return "<" + tag + " scope='col'>" + this + "</" + tag + ">";
	};
	String.prototype.embraceWithTable = function(tag,tbname,cls) {
		return "<" + tag + " id='" + tbname + "' style='margin-bottom:0;' class='" + cls + "'>" + this + "</" + tag + ">";
	};			
	String.prototype.embraceWithClass = function(tag,cls) {
		return "<" + tag + " class='" + cls + "'>" + this + "</" + tag + ">";
	};	
	String.prototype.embraceWithClassClick = function(tag,cls,onclick,id) {
		return "<" + tag + " id='" + id + "' class='" + cls + "' style='cursor:pointer;' onclick='" + onclick + "'>" + this + "</" + tag + ">";
	};
	String.prototype.embraceWithLabel = function(tag) {
		return "<" + tag + ">" + "<label style='font-weight: 500;'>" + this + "</label>" + "</" + tag + ">";
	};
	String.prototype.embraceWithInput = function(tag,inpType,users) {
		return "<" + tag + ">" + "<div class='checkbox icheck-primary'><input id='" + this + "' new='false' users='" + users + "' type='" + inpType + "'/><label for='" + this + "'></label></div>" + "</" + tag + ">";
	};
	String.prototype.embraceWithInputWidth = function(tag,inpType,users,width) {
		return "<" + tag + " width='"+width+"'>" + "<div class='checkbox icheck-primary'><input id='" + this + "' new='false' users='" + users + "' type='" + inpType + "'/><label for='" + this + "'></label></div>" + "</" + tag + ">";
	};
	String.prototype.embraceWithInputNew = function(tag,inpType,users) {
		return "<" + tag + ">" + "<input id='" + this + "' new='true' users='" + users + "' type='" + inpType + "'>" + "</" + tag + ">";
	};
	String.prototype.embraceWithInput = function(tag,inpType,users,grpname) {
		return "<" + tag + ">" + "<div class='checkbox icheck-primary'><input id='" + this + "' name='" + grpname + "' users='" + users + "' type='" + inpType + "'/><label for='" + this + "'></label></div>" + "</" + tag + ">";
	};
	String.prototype.embraceWithInputCls = function(tag,inpType,users,grpname,cls) {
		return "<" + tag + " class='" + cls + "'>" + "<div class='checkbox icheck-primary'><input id='" + this + "' name='" + grpname + "' users='" + users + "' type='" + inpType + "'/><label for='" + this + "'></label></div>" + "</" + tag + ">";
	};
	String.prototype.embraceWithInputClk = function(tag,inpType,users,onclick) {
		return "<" + tag + ">" + "<input id='" + this + "' users='" + users + "' onclick='" + onclick + "' type='" + inpType + "'>" + "</" + tag + ">";
	};
	String.prototype.embraceInput = function(tag,inpType,cls,id,onclick,tooltip) {
		return "<" + tag + " id='" + id + "' class='" + cls + "' data-toggle='tooltip' data-container='body' title='" + tooltip + "' onclick='" + onclick + "' type='" + inpType + "'>" + this + "</" + tag + ">";
	};
	String.prototype.embraceInputNew = function(tag,inpType,cls,id,tooltip) {
		return "<" + tag + " id='" + id + "' class='" + cls + "' data-toggle='tooltip' title='" + tooltip + "' type='" + inpType + "'>" + this + "</" + tag + ">";
	};


    String.prototype.sInputCLick = function(tag,inpType,cls,id,onclick,tooltip) {
		return "<" + tag + " id='" + id + "' class='" + cls + "' title='" + tooltip + "' onclick='" + onclick + "' type='" + inpType + "'>" + this + "</" + tag + ">";
	};	
	String.prototype.sInput = function(tag,inpType,cls,id,onclick,tooltip) {
		return "<div class='checkbox icheck-primary'><" + tag + " id='" + id + "' class='" + cls + "' title='" + tooltip + "'  type='" + inpType + "'></" + tag + "><label for='" + id + "'>" + this + "</label></div>";
	};
	String.prototype.xInput = function(tag,inpType,cls,id,onclick,tooltip) {
		return "<" + tag + " id='" + id + "' class='" + cls + "' title='" + tooltip + "'  type='" + inpType + "'></" + tag + ">";
	};
	String.prototype.xInputx = function(tag,inpType,cls,id,onclick,tooltip) {
		return "<" + tag + " id='" + id + "' class='" + cls + "' onclick='" + onclick + "' style='cursor:pointer;' data-toggle='tooltip' title='" + tooltip + "'  type='" + inpType + "'></" + tag + "><label for='" + id + "'>" + this + "</label>";
	};
	String.prototype.sAllTags = function(tag,cls,title) {
		return "<" + tag + " class='" + cls + "' title='" + title +"'  >" + this + "</" + tag + ">";
	};
	String.prototype.sAllTagsClk = function(tag,cls,title,onclick,id) {
		return "<" + tag + " class='" + cls + "' onclick='" + onclick + "' title='" + title +"'  >" + this + "</" + tag + ">";
	};
	String.prototype.sATags = function(tag,cls,title,onclick,id) {
		return "<" + tag + " id='" + id + "' href='#' onclick='" + onclick + "' class='" + cls + "' title='" + title +"'>" + this + "</" + tag + ">";
	};
	String.prototype.sAHrefTags = function(tag,cls,title,url,id) {
		return "<" + tag + " id='" + id + "' href='" + url + "' class='" + cls + "' title='" + title +"'  >" + this + "</" + tag + ">";
	};

	
	//This prototype function allows you to remove even array from array
	Array.prototype.removeItem = function(x) { 
		var i;
		for(i in this){
			if(this[i].toString() == x.toString()){
				this.splice(i,1)
			}
		}
	}
	
	function FormatString(str) {
        var args = str.split(',');
        for (var i = 0; i < args.length; i++) {
            var reg = new RegExp("\\{" + i + "\\}", "");             
            args[0]=args[0].replace(reg, args [i+1]);
        }
        return args[0];
    }
	
	function getDateMoment(strDate)
	{		
		var currdate = new Date();var result;var values;
		var years = moment(strDate).format("YYYY"), xyears = currdate.getFullYear();
		var months = moment(strDate).format("MM"), xmonths = currdate.getMonth()+1;
		var days = moment(strDate).format("DD"), xdays = currdate.getDate();
		var hours = moment(strDate).format("HH"), xhours = currdate.getHours();
		var minutes = moment(strDate).format("mm"), xminutes = currdate.getMinutes();
		var seconds = moment(strDate).format("ss"), xseconds = currdate.getSeconds();
		if (parseInt(years) > parseInt(xyears))
		{
			values = parseInt(years) - parseInt(xyears);
			result = "<small class='label label-default'><i class='fa fa-clock-o'></i> " + values.toString() +" year(s)</small>";
		}
		else 
		{
			if (parseInt(months) > parseInt(xmonths))
			{
				values = parseInt(months) - parseInt(xmonths);
				result = "<small class='label label-default'><i class='fa fa-clock-o'></i> " + values.toString() + " month(s)</small>";
			}
			else 
			{
				if (parseInt(days) > parseInt(xdays))
				{
					values = parseInt(days) - parseInt(xdays);
					result = "<small class='label label-success'><i class='fa fa-clock-o'></i> " + values.toString() + " day(s)</small>";
				}
				else
				{
					if (parseInt(hours) > parseInt(xhours))
					{
						values = parseInt(hours) - parseInt(xhours);
						result = "<small class='label label-primary'><i class='fa fa-clock-o'></i> " + values.toString() + " hour(s)</small>";
					}
					else
					{
						if (parseInt(minutes) > parseInt(xminutes))
						{
							values = parseInt(minutes) - parseInt(xminutes);
							result = "<small class='label label-info'><i class='fa fa-clock-o'></i> " + values.toString() + " minute(s)</small>";
						}
						else
						{
							if (parseInt(seconds) > parseInt(xseconds))
							{
								values = parseInt(seconds) - parseInt(xseconds);
								result = "<small class='label label-warning'><i class='fa fa-clock-o'></i> " + values.toString() + " second(s)</small>";
							}
							else{
								result = "<small class='label label-danger'><i class='fa fa-clock-o'></i> due</small>";
							}
						}
					}
				}				
			}
		}
		return result;
	}
	
	function openTermsCondition()
	{
		var message = '<h5 class="featurette-heading">Consent Declaration and Privacy Statement</h5>';
		message += '<p class="leads">Collection, Use and Disclosure</p>';
		message += '<p class="leads-sub">Introduction</p>';
		message += '<p class="leads-sub-i">At MPE Inc., an important part of our commitment to you is respect for your privacy and to protect your personal information. By providing information requested on this site to MPE Inc., you are consenting to US collecting, using, disclosing, and retaining your information for business purposes, analysis/reporting, and where applicable, as required by law.</p>';
		message += '<p class="leads-sub-i"><strong>The Proceeds of Crime (Money Laundering) and Terrorist Financing Act requires organizations subject to the Act to undertake certain compliance activities, such as client identification and record keeping activities.  As well, certain transactions are required to be reported to the Financial Transactions and Reports Analysis Centre of Canada (FINTRAC).</strong></p>';
		ShowInfo(message);
	}
	
	function getSpecialDateMoment(strDate)
	{	
		var currdate = new Date(); var result="";
        var years = moment(strDate).format("YYYY"), xyears = currdate.getFullYear();
		var months = moment(strDate).format("MM"), xmonths = currdate.getMonth()+1;
		var days = moment(strDate).format("DD"), xdays = currdate.getDate();
		var hours = moment(strDate).format("HH"), xhours = currdate.getHours();
		var minutes = moment(strDate).format("mm"), xminutes = currdate.getMinutes();
		var seconds = moment(strDate).format("ss"), xseconds = currdate.getSeconds();	
		var current = moment(days + "." + months + "." + years, "DD.MM.YYYY");
		var given = moment(xdays + "." + xmonths + "." + xyears, "DD.MM.YYYY");

		//Difference in number of days		
        var resultDays = 'Diff: ' + current.diff(given, 'days');
		//Difference in number of minutes	
		var resultMinutes = 'Diff: ' + current.diff(given, 'minutes');
		
		if(resultDays == 0)
		{
			result = moment(strDate).format("hh:mm A");
		}
		else if(resultDays > 0 && resultDays <= 7)
		{
			result = moment(strDate).format("dd hh:mm");
		}
		else{
			result = moment(strDate).format("DD/MM/YYYY");
		}		
		return result;
	}
	
	function getBirthDateMoment(strDate)
	{
		var spouseBday = "", contactBday = "", weddingAnniv = "";
		var result = "Birthday approaching";
		result = "Birthday past"; result = "Birthday today"; result = "Not Specified";
		return result;
	}
	
	function checkDate(strDate)
	{
		var currdate;
		var year = moment(strDate).format("YYYY");
		if (parseInt(year) > 1900)
		{
			currdate = moment(strDate).format("DD-MMM-YYYY");
		}
		return currdate;
	}
	
	function currentDate()
	{
		return moment().format("MM-YYYY");
	}
	
	function checkBirthDate(strDate)
	{
		var currdate;
		if (typeof strDate == "undefined" || strDate == null || strDate == ""  || strDate.length <= 6) return "01-1900";
		var currdate = moment(strDate).format("MMM-YYYY");
		if (currdate=="01-1800") return "01-1900";
		else return currdate;
	}
	
	/* Report */
	function createReport(dataArr)
	{
		var html = "";
		for (var i = 0; i < dataArr.length; i++) {
		    html +=  (i==dataArr.length-1?'<div class="col-md-3 col-sm-6 col-xs-12">':'<div class="col-md-3 col-sm-6 col-xs-12 remove-padding-right">');
			html +=  '<div class="info-box '+dataArr[i].color+'"><span class="info-box-icon"><i class="fa '+dataArr[i].icon+'"></i></span>';
			html +=  '<div class="info-box-content">';
			html +=  '<span class="info-box-text">'+dataArr[i].label+'</span>';
			html +=  '<span class="info-box-number">'+dataArr[i].value+'</span>';
			html +=  '<div class="progress"><div class="progress-bar" style="width: '+dataArr[i].percent+'%"></div></div>';
			html +=  '<span class="progress-description">'+dataArr[i].desc+'</span>';
			html +=  '</div>';
			html +=  '</div></div>';
		}						  					 
		return html;								  
	}
	
	/* End Report */
	
	//compare single-dimensional array and return difference
	function manageTags(array1,array2)
	{
		var difference = [];
		for( var i = 0; i < array1.length; i++ ) {
			if( $.inArray( array1[i], array2 ) == -1 ) {
					difference.push(array1[i]);
			}
		}
		return difference;
	}
	
	//compare multi-dimensional array and return difference
	function filterByDifference(array1, array2, compareField) {
	  var onlyInA = differenceInFirstArray(array1, array2, compareField);
	  var onlyInb = differenceInFirstArray(array2, array1, compareField);
	  return onlyInA.concat(onlyInb);
	}

	function differenceInFirstArray(array1, array2, compareField) {
	  return array1.filter(function (current) {
		return array2.filter(function (current_b) {
			return current_b[compareField] === current[compareField];
		  }).length == 0;
	  });
	}
	
	//sort array
	function createSorter(propName) {
		return function (a,b) {
			// The following won't work for strings
			// return a[propName] - b[propName];
			var aVal = a[propName], bVal = b[propName] ;
			return aVal > bVal ? 1 : (aVal < bVal ?  - 1 : 0);

		};
	}
	
	function sortArray(){
		return function(a, b) {
			return a - b;
		};
	}
	
	//var str = fixedEncodeURIComponent("Manager's Bulletins");
	function fixedEncodeURIComponent(src) {
		return encodeURIComponent(src).replace(/[!'()*]/g, function (c) {
			return '%' + c.charCodeAt(0).toString(16) + '%' + c.charCodeAt(0).toString(16);
		});
	}


	function TruncateWord(myTag,limit)
	{
		if (myTag.length > limit) {
		  var truncated = myTag.trim().substring(0, limit).split(" ").slice(0, -1).join(" ") + "…";
		  return truncated;
		}
		return myTag;
	}

	function addslashes (str) {
		return (str+'').replace(/[\\"']/g, '\\$&').replace(/\u0000/g, '\\0');
	}	

	function str2json(str, val, obj){
		var obj= str.indexOf("'") != -1 ? JSON.parse(str.replace(/'/g, "\"")) : JSON.parse(str);
		return (val === undefined ? obj : obj[val])
	}

	var htmlEnDeCode = (function() {
		var charToEntityRegex,
			entityToCharRegex,
			charToEntity,
			entityToChar;

		function resetCharacterEntities() {
			charToEntity = {};
			entityToChar = {};
			// add the default set
			addCharacterEntities({
				'&amp;'     :   '&',
				'&gt;'      :   '>',
				'&lt;'      :   '<',
				'&quot;'    :   '"',
				'&#39;'     :   "'"
			});
		}

		function addCharacterEntities(newEntities) {
			var charKeys = [],
				entityKeys = [],
				key, echar;
			for (key in newEntities) {
				echar = newEntities[key];
				entityToChar[key] = echar;
				charToEntity[echar] = key;
				charKeys.push(echar);
				entityKeys.push(key);
			}
			charToEntityRegex = new RegExp('(' + charKeys.join('|') + ')', 'g');
			entityToCharRegex = new RegExp('(' + entityKeys.join('|') + '|&#[0-9]{1,5};' + ')', 'g');
		}

		function htmlEncode(value){
			var htmlEncodeReplaceFn = function(match, capture) {
				return charToEntity[capture];
			};

			return (!value) ? value : String(value).replace(charToEntityRegex, htmlEncodeReplaceFn);
		}

		function htmlDecode(value) {
			var htmlDecodeReplaceFn = function(match, capture) {
				return (capture in entityToChar) ? entityToChar[capture] : String.fromCharCode(parseInt(capture.substr(2), 10));
			};

			return (!value) ? value : String(value).replace(entityToCharRegex, htmlDecodeReplaceFn);
		}

		resetCharacterEntities();

		return {
			htmlEncode: htmlEncode,
			htmlDecode: htmlDecode
		};
	})();

	jQuery.loadCSS = function(url) {
		if (!$('link[href="' + url + '"]').length)
			$('head').append('<link rel="stylesheet" type="text/css" href="' + url + '">');
	}
	
	
