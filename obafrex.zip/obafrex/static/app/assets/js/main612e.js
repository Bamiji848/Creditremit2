(function($){
	"use strict";
	jQuery(document).on('ready', function () {
		
		// Header Sticky
		$(window).on('scroll',function() {
            if ($(this).scrollTop() > 120){  
                $('.navbar-area').addClass("is-sticky");
            }
            else{
                $('.navbar-area').removeClass("is-sticky");
            }
        });

		// Mean Menu
		jQuery('.mean-menu').meanmenu({
			meanScreenWidth: "991"
		});
		
		// Nice Select JS
		$('select').niceSelect();
		
		// Odometer JS
		$('.odometer').appear(function(e) {
			var odo = $(".odometer");
			odo.each(function() {
				var countNumber = $(this).attr("data-count");
				$(this).html(countNumber);
			});
		});

		// Video Popup JS
		$('.popup-youtube').magnificPopup({
            disableOn: 320,
            type: 'iframe',
            mainClass: 'mfp-fade',
            removalDelay: 160,
            preloader: false,
            fixedContentPos: false
        });

		// Feedback Carousel
		var $imagesSlider = $(".feedback-slides .client-feedback>div"),
		$thumbnailsSlider = $(".client-thumbnails>div");
		// images options
		$imagesSlider.slick({
			speed:300,
			slidesToShow:1,
			slidesToScroll:1,
			cssEase:'linear',
			fade:true,
			autoplay: true,
			draggable:true,
			asNavFor:".client-thumbnails>div",
			prevArrow:'.client-feedback .prev-arrow',
			nextArrow:'.client-feedback .next-arrow'
		});
		// Thumbnails options
		$thumbnailsSlider.slick({
			speed:300,
			slidesToShow:5,
			slidesToScroll:1,
			cssEase:'linear',
			autoplay: true,
			centerMode:true,
			draggable:false,
			focusOnSelect:true,
			asNavFor:".feedback-slides .client-feedback>div",
			prevArrow:'.client-thumbnails .prev-arrow',
			nextArrow:'.client-thumbnails .next-arrow',
		});
		var $caption = $('.feedback-slides .caption');
		var captionText = $('.client-feedback .slick-current img').attr('alt');
		updateCaption(captionText);
		$imagesSlider.on('beforeChange', function(event, slick, currentSlide, nextSlide){
			$caption.addClass('hide');
		});
		$imagesSlider.on('afterChange', function(event, slick, currentSlide, nextSlide){
			captionText = $('.client-feedback .slick-current img').attr('alt');
			updateCaption(captionText);
		});
		function updateCaption(text) {
			// if empty, add a no breaking space
			if (text === '') {
				text = '&nbsp;';
			}
			$caption.html(text);
			$caption.removeClass('hide');
		}

		// FAQ Accordion
        $(function() {
            $('.accordion').find('.accordion-title').on('click', function(){
                // Adds Active Class
                $(this).toggleClass('active');
                // Expand or Collapse This Panel
                $(this).next().slideToggle('fast');
                // Hide The Other Panels
                $('.accordion-content').not($(this).next()).slideUp('fast');
                // Removes Active Class From Other Titles
                $('.accordion-title').not($(this)).removeClass('active');		
            });
        });

		// Go to Top
        $(function(){
            // Scroll Event
            $(window).on('scroll', function(){
                var scrolled = $(window).scrollTop();
                if (scrolled > 600) $('.go-top').addClass('active');
                if (scrolled < 600) $('.go-top').removeClass('active');
            });  
            // Click Event
            $('.go-top').on('click', function() {
                $("html, body").animate({ scrollTop: "0" },  500);
            });
        });
		
	});
	
	// WOW JS
	$(window).on ('load', function (){
        if ($(".wow").length) { 
            var wow = new WOW({
            boxClass:     'wow',      // animated element css class (default is wow)
            animateClass: 'animated', // animation css class (default is animated)
            offset:       20,          // distance to the element when triggering the animation (default is 0)
            mobile:       true, // trigger animations on mobile devices (default is true)
            live:         true,       // act on asynchronously loaded content (default is true)
          });
          wow.init();
        }
	});
	
	// Preloader
	jQuery(window).on('load', function() {
		$('.preloader').fadeOut();
	});
	
	if ($('#btnLogin').length) { 
		$('.formsubmit').keydown(function(event){ 
			var keyCode = (event.keyCode ? event.keyCode : event.which);   
			if (keyCode == 13) {
				$('#btnLogin').trigger('click');
			}
		});
	}
	
	if ($('.contactform').length) { 
		$('.contactform').keydown(function(event){ 
			var keyCode = (event.keyCode ? event.keyCode : event.which);   
			if (keyCode == 13) {
				$('#btnSubmit').trigger('click');
			}
		});
	}


}(jQuery));

function open_TermsCondition()
{
	var message = '<h5 class="featurette-heading">Consent Declaration and Privacy Statement</h5>';
	message += '<p class="leads">Collection, Use and Disclosure</p>';
	message += '<p class="leads-sub">Introduction</p>';
	message += '<p class="leads-sub-i">At MPE Inc., an important part of our commitment to you is respect for your privacy and to protect your personal information. By providing information requested on this site to MPE Inc., you are consenting to US collecting, using, disclosing, and retaining your information for business purposes, analysis/reporting, and where applicable, as required by law.</p>';
	message += '<p class="leads-sub-i"><strong>The Proceeds of Crime (Money Laundering) and Terrorist Financing Act requires organizations subject to the Act to undertake certain compliance activities, such as client identification and record keeping activities.  As well, certain transactions are required to be reported to the Financial Transactions and Reports Analysis Centre of Canada (FINTRAC).</strong></p>';
	message += '<p class="leads-sub-i">At Maple PayExchange Inc. ("Maple Pay" or "MPE Inc." or "Us" or "Our" or "We"), We work to ensure fast remittance of money between Nigeria and Canada.</p>';
	message += '<p class="leads-sub-i">We want you - the Client - to understand who We are, what information We will collect from you and how We process your personal information. We created this Privacy Statement ("Privacy Statement") to provide you with greater transparency into our privacy practices and principles, as well as to inform you - the Client - of your individual rights.</p>';
	message += '<p class="leads-sub-i">We also want you to understand that MPE Inc. complies with all applicable privacy laws and regulations in all our operations.</p>';
	message += '<p class="leads-sub">This Privacy Statement:</p>';
	message += '<p class="leads-sub-i">We ask that you read this Privacy Statement carefully and indicate your acceptance of its terms by clicking the &apos;Accept&apos; button. Our processing of your personal data is based upon the consent you provide when clicking the Accept button below.</p>';
	message += '<p class="leads-sub">Personal Data Held by MPE Inc.</p>';
	message += '<p class="leads-sub-i">MPE Inc. collects personal data submitted by you as part of the business process and as directed by FINTRAC (Financial Transactions and Reports Analysis Centre of Canada). Personal data is held on an externally hosted database in the US and replicated in Europe but will be subject to the data privacy and protection laws and regulations governing Canadian business operations.</p>';
	message += '<p class="leads-sub-i">Further, your personal data may, if necessary for business purposes, be transferred to FINTRAC (regulatory authority) if required by law.<ul class="mylist"><li>1. The collection of the name, address, date of birth and occupation of the account holder are required by law;</li><li>2. The presentation of documentary evidence to prove identity is required by law.</li></ul></p>';
	message += '<p class="leads-sub-i">When submitting your profile and registering an account with MPE Inc., you certify that all of your personal information entered in the profile and system is true and correct, and you understand that dishonesty could result in criminal charges.</p>';
	message += '<p class="leads-sub-i">We collect and process personally identifiable information to meet legal, regulatory and compliance requirements. You are not required to provide us with your personal data. However, if you do not provide your personal data, We will not be able to process your request.</p>';
	message += '<p class="leads-sub-i">We ask that you carefully read this Privacy Statement before you click the acceptance button below (&apos;I understand and agree to the above terms&apos;). If you do not accept the terms in the Statement, you will not be able to create a Profile on this website.</p>';
	message += '<p class="leads-sub">Disclosure of Personal Data</p>';
	message += '<p class="leads-sub-i">As a general matter, your personal data will be disclosed only in limited circumstances. Personal data may be disclosed to public authorities and law enforcement agencies as required or permitted by all applicable laws.</p>';
	message += '<p class="leads-sub">Use of Personal Information</p>';
	message += '<p class="leads-sub-i">The information that you submit on Our Company Site will be used for MPE Inc.&apos;s business purposes, as permitted by local law, including:<ul class="mylist"><li>To verify your identity;</li><li>To provide you with updates or notifications</li><li>To respond to your enquiries and communicate with you; and</li><li>To comply with or monitor compliance with any applicable law or regulation</li></ul></p>';
	message += '<p class="leads-sub-i">MPE Inc. may also use the information as we believe to be necessary or appropriate: (a) under applicable law, (b) to comply with legal process; (c) to respond to requests from public and government authorities including public and government authorities outside your country of residence; (d) to enforce our terms and conditions; (e) to protect our operations; (f) to protect our rights, privacy, safety or property, you or others; and (g) to allow us to pursue available remedies or limit the damages that we may sustain.</p>';
	message += '<p class="leads-sub">Retention and Storage of Data</p>';
	message += '<p class="leads-sub-i">We ask you to provide accurate and up-to-date information and encourage you to regularly update your personal data. You may review and modify your profile information at any time. However, please know that storage of your personal data will be done in accordance with the applicable laws and regulations governing MPE Inc. operations.</p>';
	message += '<p class="leads-sub">Your Rights, Access and Correction of Personal Information</p>';
	message += '<p class="leads-sub-i">As indicated above, MPE Inc. values the importance of your personal information that it collects from you, and strives to give you as much control over it as possible.</p>';
	message += '<p class="leads-sub-i">As such, you are entitled to receive further information on the personal data We store and process about you. You are also entitled to access, review, update and correct your personal information in the event of a change/s or inaccuracies by logging in and updating your account information. We encourage you to promptly update your personal information if it changes or is inaccurate.</p>';
	message += '<p class="leads-sub">Data Security</p>';
	message += '<p class="leads-sub-i">MPE Inc. implements organizational, technical and administrative measures to protect personal information within our organization. Unfortunately, no data transmission or storage system can be guaranteed to be 100% secure. If you have reason to believe that your interaction with us is no longer secure (for example, if you feel that the security of any account you might have with us has been compromised), please immediately notify us of the problem by contacting us in accordance with the "Contact Us" section above.</p>';
	message += '<p class="leads-sub-i">If you can accept the conditions above, please click ACCEPT and proceed, if not, please click DECLINE and thereafter please leave the page.</p>';
	ShowInfoXp(message);
}